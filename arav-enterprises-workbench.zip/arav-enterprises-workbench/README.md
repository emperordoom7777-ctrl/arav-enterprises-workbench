# Arav Enterprises Workbench

**Version 1.0 - Free Public Launch**

Arav Enterprises Workbench is an AI-powered business workspace for business owners, freelancers and small businesses. Users create a free account, describe their business once, and generate customer replies, marketing posts, emails, quotations, proposals, summaries and more. Every draft is written with the user's business profile as context.

Version 1.0 is completely free. There are **no payments, subscriptions, card storage, bank details or withdrawals** anywhere in the code. The data model carries a `plan` field (always `FREE`) so a paid "Workbench Pro" can be added later without a rewrite.

## Features

- Public landing page (hero, features, how it works, reviews, FAQ)
- Sign up, log in, log out (NextAuth credentials, bcrypt hashing)
- Short, skippable onboarding
- Dashboard with stats, quick actions and recent activity
- Business Profile that feeds every AI prompt
- AI Workspace with 13 task types; Copy, Save, Regenerate, Improve, Shorten, Expand
- Generation History (search, filter, open, copy, save, delete) and Saved Content
- Free usage limits (daily + monthly) set by environment variables
- Customer reviews with admin moderation (new reviews are hidden until approved)
- Settings: name, theme (light / dark / system), delete account
- Admin dashboard at `/admin`: overview, users, analytics, AI usage, review moderation, activity log, settings

## Tech stack

Next.js 14 (App Router), TypeScript, Tailwind CSS, Prisma, PostgreSQL, NextAuth v4, Zod.

## Installation

Requirements: Node.js 18.17+ and a PostgreSQL database (local, Neon, Supabase, Railway, etc).

```bash
npm install
cp .env.example .env     # then fill in the values
```

## Environment variables

| Variable | Purpose |
| --- | --- |
| `DATABASE_URL` | PostgreSQL connection string |
| `NEXTAUTH_URL` | Public URL of the app (`http://localhost:3000` locally) |
| `NEXTAUTH_SECRET` | Long random string. Generate with `openssl rand -base64 32` |
| `OPENAI_API_KEY` | AI provider key. Server-side only, never sent to the browser |
| `OPENAI_MODEL` | Model name (default `gpt-4o-mini`) |
| `OPENAI_BASE_URL` | Optional OpenAI-compatible endpoint |
| `FREE_MONTHLY_GENERATION_LIMIT` | Free generations per user per month (default 100) |
| `FREE_DAILY_GENERATION_LIMIT` | Free generations per user per day (default 20) |
| `ADMIN_EMAIL`, `ADMIN_PASSWORD`, `ADMIN_NAME` | Used only by `npm run db:seed` |

Never commit your real `.env`.

## Database and Prisma setup

```bash
# Create tables (development)
npx prisma migrate dev --name init

# or, for a quick start without migration files
npm run db:push
```

In production, commit the generated `prisma/migrations` folder and run `npm run db:deploy`.

Models: `User`, `Account`, `Session`, `VerificationToken`, `BusinessProfile`, `Generation`, `UsageRecord`, `Review`, `Activity`. Deleting a user cascades to all of their data. Activity rows keep only an event type and a short note, and the user link is cleared on deletion.

## Authentication setup

1. Set `NEXTAUTH_URL` and `NEXTAUTH_SECRET`.
2. Users sign up at `/signup` and log in at `/login`. Sessions are JWT-based and last 14 days.
3. **Create the first administrator:** put `ADMIN_EMAIL` and `ADMIN_PASSWORD` (10+ characters) in `.env`, then run:

   ```bash
   npm run db:seed
   ```

   Log in with that account, and the Admin dashboard link appears in the sidebar (`/admin`). Roles are verified against the database on the server for every admin page and API route. If you promote an existing user, they must log out and back in.

Email verification and password reset are not part of Version 1.0.

## AI provider setup

1. Create an API key with your provider and set `OPENAI_API_KEY`.
2. Optionally set `OPENAI_MODEL` or `OPENAI_BASE_URL`.
3. Restart the app.

All AI calls run in `src/app/api/generate/route.ts` through the provider layer in `src/lib/ai/`. To add another provider, implement the `AIProvider` interface in `src/lib/ai/provider.ts` and return it from `getAIProvider()`. Without a key, the workspace shows: "AI generation is currently not configured. Please contact the administrator." No fake responses are generated.

## Running locally

```bash
npm run dev          # http://localhost:3000
npm run typecheck    # TypeScript check
npm run build        # production build
npm run start        # run the production build
```

## Production deployment

1. Provision PostgreSQL and set `DATABASE_URL`.
2. Set `NEXTAUTH_URL` to your real https domain and a strong `NEXTAUTH_SECRET`.
3. Set `OPENAI_API_KEY` and your usage limits.
4. Run `npm run db:deploy`, then `npm run db:seed` once to create the admin.
5. Build and start (`npm run build && npm run start`), or deploy to Vercel / any Node host.

Production notes:

- The built-in rate limiter (`src/lib/rate-limit.ts`) is in-memory and per instance. On serverless or multi-instance hosting, replace it with a shared store such as Redis.
- Usage is checked before generation and recorded after it. Under heavy parallel requests a user could exceed a limit by a few generations.
- Usage dates use UTC.

## Security summary

- Every protected page re-checks the session on the server, and middleware adds an edge guard.
- Every user-data query is scoped by the signed-in user's id (ownership is part of the query itself).
- Admin pages and routes verify `role === ADMIN` against the database.
- Inputs are validated with Zod; passwords are hashed with bcrypt (cost 12).
- API errors are returned as friendly messages; technical details are logged on the server only.
- Reviews start unapproved; editing an approved review sends it back to moderation.

## Project layout

```
prisma/             schema and admin seed script
src/app/            pages and API routes (App Router)
src/components/     shared UI
src/lib/            auth, db, AI provider, usage, validators, admin queries
```

## Roadmap to Workbench Pro

Add a billing module and plan-based limits (reading `User.plan`), team accounts, and further AI tools. Version 1.0 keeps these concerns out of the core flows.
