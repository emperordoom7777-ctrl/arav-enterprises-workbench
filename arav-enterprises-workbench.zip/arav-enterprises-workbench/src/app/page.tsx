import Link from "next/link";
import { getServerSession } from "next-auth";
import {
  Bot, MessageSquareReply, Megaphone, Mail, ShoppingBag, Building2, History, Bookmark, BarChart3, Star,
  UserPlus, Settings2, MousePointerClick, Sparkles, ChevronDown,
} from "lucide-react";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { MarketingNav } from "@/components/marketing-nav";
import { Logo } from "@/components/logo";
import { Stars } from "@/components/ui";
import { formatDate, initials, publicName } from "@/lib/utils";

export const dynamic = "force-dynamic";

const features = [
  { icon: Bot, title: "AI Business Assistant", text: "Thirteen task types for the writing you do every day, from quotes to meeting notes." },
  { icon: MessageSquareReply, title: "Smart Customer Replies", text: "Answer customers quickly in a tone that sounds like your business." },
  { icon: Megaphone, title: "Marketing Content Generator", text: "Posts, captions and announcements shaped around your audience." },
  { icon: Mail, title: "Email Generator", text: "Complete emails with subject lines, ready to review and send." },
  { icon: ShoppingBag, title: "Product Description Generator", text: "Clear descriptions that lead with what your customer cares about." },
  { icon: Building2, title: "Business Profile Context", text: "Tell Workbench about your business once. Every draft uses it automatically." },
  { icon: History, title: "Generation History", text: "Search and filter everything you have created, and reopen it any time." },
  { icon: Bookmark, title: "Saved Content", text: "Keep your best drafts in one place, ready to copy." },
  { icon: BarChart3, title: "Usage Analytics", text: "See how many generations you have used and how many remain." },
  { icon: Star, title: "Customer Reviews", text: "Read what other users say, and share your own experience." },
];

const steps = [
  { icon: UserPlus, title: "Create your free account", text: "Sign up with your name, email and a password. No card needed." },
  { icon: Settings2, title: "Set up your business profile", text: "Add your business name, audience and brand tone in a minute." },
  { icon: MousePointerClick, title: "Choose the business task you need", text: "Pick a reply, post, email, quotation or any of ten other tasks." },
  { icon: Sparkles, title: "Generate professional content", text: "Review the draft, then copy it, refine it or save it." },
];

const faqs = [
  { q: "Is Arav Enterprises Workbench really free?", a: "Yes. Version 1.0 is free to use. You do not need a payment method to sign up." },
  { q: "Are there usage limits?", a: "There is a daily and monthly generation limit so the service stays fast for everyone. You can see your usage on the Usage page." },
  { q: "Does the AI know about my business?", a: "It does once you fill in your Business Profile. Your business name, audience, products and brand tone are included with every request." },
  { q: "Is my content private?", a: "Your generations, saved content and business profile are visible only to your account. Administrators see usage totals, not the content you write." },
  { q: "Can I trust the output as-is?", a: "Treat every draft as a starting point. Check names, prices, dates and claims before you send or publish." },
  { q: "How do reviews work?", a: "Signed-in users can submit one review. Each review is checked by an administrator before it appears publicly." },
];

export default async function LandingPage() {
  const session = await getServerSession(authOptions);

  let reviews: {
    id: string; rating: number; title: string; message: string; businessName: string | null; createdAt: Date; user: { name: string };
  }[] = [];
  try {
    reviews = await prisma.review.findMany({
      where: { isApproved: true, status: "APPROVED" },
      orderBy: { createdAt: "desc" },
      take: 9,
      select: { id: true, rating: true, title: true, message: true, businessName: true, createdAt: true, user: { select: { name: true } } },
    });
  } catch {
    reviews = []; // landing page must still render if the database is unreachable
  }

  return (
    <div id="home">
      <MarketingNav signedIn={Boolean(session?.user)} />

      {/* Hero */}
      <section className="mx-auto grid max-w-6xl gap-12 px-4 pb-16 pt-14 sm:px-6 sm:pt-20 lg:grid-cols-[1.05fr_1fr] lg:items-center lg:pb-24">
        <div className="rise">
          <p className="mb-5 inline-flex items-center gap-2 rounded-full border border-line bg-surface px-3 py-1 text-xs font-medium text-muted">
            <span className="h-1.5 w-1.5 rounded-full bg-success" /> Version 1.0 is free for everyone
          </p>
          <h1 className="text-4xl font-semibold leading-[1.05] sm:text-5xl lg:text-[3.5rem]">
            Your AI-Powered Business Workspace.
          </h1>
          <p className="mt-5 max-w-xl text-lg leading-relaxed text-muted">
            Create professional business content, manage your AI workflow and save valuable time with Arav Enterprises Workbench.
          </p>
          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <Link href={session?.user ? "/dashboard" : "/signup"} className="btn btn-primary px-6 py-3 text-base">Get Started Free</Link>
            <a href="#features" className="btn btn-secondary px-6 py-3 text-base">Explore Features</a>
          </div>
        </div>

        {/* Illustrative product preview (static mock, clearly labelled) */}
        <div className="relative" aria-hidden>
          <div className="card overflow-hidden shadow-lift">
            <div className="flex items-center justify-between border-b border-line px-4 py-3">
              <div className="flex gap-1.5">
                <span className="h-2.5 w-2.5 rounded-full bg-line" /><span className="h-2.5 w-2.5 rounded-full bg-line" /><span className="h-2.5 w-2.5 rounded-full bg-line" />
              </div>
              <span className="text-xs text-muted">AI Workspace · illustration</span>
            </div>
            <div className="grid sm:grid-cols-[0.9fr_1.1fr]">
              <div className="space-y-3 border-b border-line p-4 sm:border-b-0 sm:border-r">
                <div className="rounded-lg border border-line bg-sunken px-3 py-2 text-xs font-medium">Customer Reply</div>
                <div className="rounded-lg border border-line px-3 py-2 text-xs leading-relaxed text-muted">
                  Customer asks if the blue sofa ships to Lucknow and how long it takes.
                </div>
                <div className="rounded-lg bg-accent px-3 py-2 text-center text-xs font-medium text-accent-ink">Generate</div>
              </div>
              <div className="space-y-2 p-4">
                <p className="text-[11px] font-medium text-muted">Example output</p>
                <p className="text-sm leading-relaxed">
                  Hello, thank you for asking! Yes, we can deliver the sofa to your city. Please share your pin code and we will confirm the delivery time.
                </p>
                <div className="flex gap-2 pt-2">
                  <span className="badge">Copy</span><span className="badge">Shorten</span><span className="badge">Save</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section id="features" className="border-y border-line bg-surface py-20">
        <div className="mx-auto max-w-6xl px-4 sm:px-6">
          <h2 className="max-w-xl text-3xl font-semibold sm:text-4xl">Everything you need for everyday business writing</h2>
          <p className="mt-3 max-w-2xl text-muted">One workspace for the messages, posts and documents that keep a small business moving.</p>
          <div className="mt-12 grid gap-px overflow-hidden rounded-2xl border border-line bg-line sm:grid-cols-2 lg:grid-cols-3">
            {features.map((f) => (
              <div key={f.title} className="bg-surface p-6 transition-colors hover:bg-sunken/60">
                <f.icon className="h-5 w-5 text-accent" aria-hidden />
                <h3 className="mt-4 text-base font-semibold">{f.title}</h3>
                <p className="mt-1.5 text-sm leading-relaxed text-muted">{f.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How it works */}
      <section id="how-it-works" className="mx-auto max-w-6xl px-4 py-20 sm:px-6">
        <h2 className="max-w-xl text-3xl font-semibold sm:text-4xl">From sign-up to first draft in minutes</h2>
        <ol className="mt-12 grid gap-4 md:grid-cols-4">
          {steps.map((s, i) => (
            <li key={s.title} className="card relative p-6">
              <span className="flex h-9 w-9 items-center justify-center rounded-full bg-accent-soft font-display text-sm font-semibold text-accent">{i + 1}</span>
              <s.icon className="mt-5 h-5 w-5 text-muted" aria-hidden />
              <h3 className="mt-3 font-semibold">{s.title}</h3>
              <p className="mt-1.5 text-sm leading-relaxed text-muted">{s.text}</p>
            </li>
          ))}
        </ol>
      </section>

      {/* Reviews */}
      <section id="reviews" className="border-y border-line bg-surface py-20">
        <div className="mx-auto max-w-6xl px-4 sm:px-6">
          <h2 className="text-3xl font-semibold sm:text-4xl">See what our users are saying.</h2>
          {reviews.length === 0 ? (
            <div className="card mt-10 flex flex-col items-center px-6 py-14 text-center">
              <Star className="h-8 w-8 text-warn" aria-hidden />
              <p className="mt-4 max-w-md text-base">
                Be one of the first people to share your experience with Arav Enterprises Workbench.
              </p>
              <Link href={session?.user ? "/reviews" : "/signup"} className="btn btn-primary mt-6">
                {session?.user ? "Write a review" : "Create a free account"}
              </Link>
            </div>
          ) : (
            <div className="mt-10 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {reviews.map((r) => (
                <article key={r.id} className="card flex flex-col p-6">
                  <Stars value={r.rating} />
                  <h3 className="mt-3 font-semibold">{r.title}</h3>
                  <p className="mt-2 flex-1 whitespace-pre-line text-sm leading-relaxed text-muted">{r.message}</p>
                  <footer className="mt-5 flex items-center gap-3 border-t border-line pt-4">
                    <span className="flex h-9 w-9 items-center justify-center rounded-full bg-accent-soft text-xs font-semibold text-accent">{initials(r.user.name)}</span>
                    <div className="min-w-0 text-sm">
                      <p className="truncate font-medium">{publicName(r.user.name)}</p>
                      <p className="truncate text-xs text-muted">{[r.businessName, formatDate(r.createdAt)].filter(Boolean).join(" · ")}</p>
                    </div>
                  </footer>
                </article>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* FAQ */}
      <section id="faq" className="mx-auto max-w-3xl px-4 py-20 sm:px-6">
        <h2 className="text-3xl font-semibold sm:text-4xl">Frequently asked questions</h2>
        <div className="mt-10 divide-y divide-line rounded-2xl border border-line bg-surface">
          {faqs.map((f) => (
            <details key={f.q} className="group px-5 py-4">
              <summary className="flex cursor-pointer list-none items-center justify-between gap-4 font-medium [&::-webkit-details-marker]:hidden">
                {f.q}
                <ChevronDown className="h-4 w-4 shrink-0 text-muted transition-transform group-open:rotate-180" aria-hidden />
              </summary>
              <p className="mt-3 text-sm leading-relaxed text-muted">{f.a}</p>
            </details>
          ))}
        </div>
      </section>

      {/* Closing CTA */}
      <section className="mx-auto max-w-6xl px-4 pb-20 sm:px-6">
        <div className="rounded-3xl bg-ink px-6 py-14 text-center text-canvas sm:px-12">
          <h2 className="mx-auto max-w-xl text-3xl font-semibold sm:text-4xl">Start your first draft today.</h2>
          <p className="mx-auto mt-3 max-w-md text-canvas/70">Free to use. No payment details required.</p>
          <Link href={session?.user ? "/dashboard" : "/signup"} className="btn mt-8 bg-canvas px-6 py-3 text-base text-ink hover:opacity-90">
            Get Started Free
          </Link>
        </div>
      </section>

      <footer className="border-t border-line">
        <div className="mx-auto flex max-w-6xl flex-col items-start justify-between gap-4 px-4 py-8 text-sm text-muted sm:flex-row sm:items-center sm:px-6">
          <Logo />
          <p>© {new Date().getFullYear()} Arav Enterprises. Workbench Version 1.0.</p>
        </div>
      </footer>
    </div>
  );
}
