import { NextResponse } from "next/server";
import { route } from "@/lib/api";
import { requireApiAdmin } from "@/lib/session";
import { getAnalytics, getOverview } from "@/lib/admin-data";

export const GET = route(async () => {
  await requireApiAdmin();
  const [overview, analytics] = await Promise.all([getOverview(), getAnalytics()]);
  return NextResponse.json({ overview, analytics });
});
