import { NextResponse } from "next/server";
import { route } from "@/lib/api";
import { requireApiAdmin } from "@/lib/session";
import { adminReviewQuerySchema } from "@/lib/validators";
import { listReviews } from "@/lib/admin-data";

export const GET = route(async (req) => {
  await requireApiAdmin();
  const { status } = adminReviewQuerySchema.parse(Object.fromEntries(new URL(req.url).searchParams.entries()));
  return NextResponse.json({ reviews: await listReviews(status) });
});
