import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { ApiError, route } from "@/lib/api";
import { requireApiAdmin } from "@/lib/session";
import { adminReviewActionSchema } from "@/lib/validators";
import { logActivity } from "@/lib/activity";

type Ctx = { params: { id: string } };

export const PATCH = route<Ctx>(async (req, { params }) => {
  const admin = await requireApiAdmin();
  const { action } = adminReviewActionSchema.parse(await req.json());
  const approve = action === "approve";

  const result = await prisma.review.updateMany({
    where: { id: params.id },
    data: {
      isApproved: approve,
      status: approve ? "APPROVED" : "REJECTED",
      moderatedAt: new Date(),
    },
  });
  if (result.count === 0) throw new ApiError(404, "That review no longer exists.", "NOT_FOUND");

  await logActivity("REVIEW_MODERATED", admin.id, approve ? "approved" : "rejected");
  return NextResponse.json({ ok: true });
});

export const DELETE = route<Ctx>(async (_req, { params }) => {
  const admin = await requireApiAdmin();
  const result = await prisma.review.deleteMany({ where: { id: params.id } });
  if (result.count === 0) throw new ApiError(404, "That review no longer exists.", "NOT_FOUND");
  await logActivity("REVIEW_MODERATED", admin.id, "deleted");
  return NextResponse.json({ ok: true });
});
