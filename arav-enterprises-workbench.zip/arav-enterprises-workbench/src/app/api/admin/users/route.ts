import { NextResponse } from "next/server";
import { route } from "@/lib/api";
import { requireApiAdmin } from "@/lib/session";
import { adminUsersQuerySchema } from "@/lib/validators";
import { listUsers } from "@/lib/admin-data";

export const GET = route(async (req) => {
  await requireApiAdmin();
  const { q, page } = adminUsersQuerySchema.parse(Object.fromEntries(new URL(req.url).searchParams.entries()));
  return NextResponse.json(await listUsers(q, page));
});
