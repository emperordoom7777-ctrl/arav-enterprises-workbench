import { NextResponse } from "next/server";
import { route } from "@/lib/api";
import { requireApiAdmin } from "@/lib/session";
import { listActivity } from "@/lib/admin-data";

export const GET = route(async () => {
  await requireApiAdmin();
  return NextResponse.json({ activity: await listActivity() });
});
