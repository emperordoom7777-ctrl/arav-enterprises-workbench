import { NextResponse } from "next/server";
import { route } from "@/lib/api";
import { requireApiUser } from "@/lib/session";
import { getUsage } from "@/lib/usage";

export const GET = route(async () => {
  const user = await requireApiUser();
  return NextResponse.json({ usage: await getUsage(user.id) });
});
