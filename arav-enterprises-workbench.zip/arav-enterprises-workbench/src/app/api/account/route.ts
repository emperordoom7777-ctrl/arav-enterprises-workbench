import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { ApiError, route } from "@/lib/api";
import { requireApiUser } from "@/lib/session";
import { accountDeleteSchema, accountUpdateSchema } from "@/lib/validators";
import { logActivity } from "@/lib/activity";

export const PATCH = route(async (req) => {
  const user = await requireApiUser();
  const { name } = accountUpdateSchema.parse(await req.json());
  const updated = await prisma.user.update({
    where: { id: user.id },
    data: { name },
    select: { id: true, name: true, email: true },
  });
  return NextResponse.json({ user: updated });
});

export const DELETE = route(async (req) => {
  const user = await requireApiUser();
  accountDeleteSchema.parse(await req.json().catch(() => ({})));

  if (user.role === "ADMIN") {
    const admins = await prisma.user.count({ where: { role: "ADMIN" } });
    if (admins <= 1) {
      throw new ApiError(400, "You are the only administrator. Promote another admin before deleting this account.", "LAST_ADMIN");
    }
  }

  // Logged first without a user reference: no personal data is kept after deletion.
  await logActivity("ACCOUNT_DELETED", null);
  await prisma.user.delete({ where: { id: user.id } }); // cascades to all of the user's data
  return NextResponse.json({ ok: true });
});
