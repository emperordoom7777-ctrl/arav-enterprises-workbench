import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { ApiError, route } from "@/lib/api";
import { requireApiUser } from "@/lib/session";
import { reviewSchema } from "@/lib/validators";

export const GET = route(async () => {
  const user = await requireApiUser();
  const review = await prisma.review.findUnique({ where: { userId: user.id } });
  return NextResponse.json({ review });
});

/** Editing sends the review back to moderation so approved text can't be swapped silently. */
export const PUT = route(async (req) => {
  const user = await requireApiUser();
  const data = reviewSchema.parse(await req.json());

  const result = await prisma.review.updateMany({
    where: { userId: user.id },
    data: { ...data, isApproved: false, status: "PENDING", moderatedAt: null },
  });
  if (result.count === 0) throw new ApiError(404, "You haven't submitted a review yet.", "NOT_FOUND");

  const review = await prisma.review.findUnique({ where: { userId: user.id } });
  return NextResponse.json({ review });
});

export const DELETE = route(async () => {
  const user = await requireApiUser();
  const result = await prisma.review.deleteMany({ where: { userId: user.id } });
  if (result.count === 0) throw new ApiError(404, "You haven't submitted a review yet.", "NOT_FOUND");
  return NextResponse.json({ ok: true });
});
