import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { ApiError, route } from "@/lib/api";
import { requireApiUser } from "@/lib/session";
import { reviewSchema } from "@/lib/validators";
import { publicName } from "@/lib/utils";
import { logActivity } from "@/lib/activity";

/** Public: approved reviews only. Exposes a shortened display name, never email or ids of users. */
export const GET = route(async () => {
  const reviews = await prisma.review.findMany({
    where: { isApproved: true, status: "APPROVED" },
    orderBy: { createdAt: "desc" },
    take: 24,
    select: {
      id: true,
      rating: true,
      title: true,
      message: true,
      businessName: true,
      createdAt: true,
      user: { select: { name: true } },
    },
  });
  return NextResponse.json({
    reviews: reviews.map(({ user, ...r }) => ({ ...r, author: publicName(user.name) })),
  });
});

/** Authenticated: submit your single review (starts as pending). */
export const POST = route(async (req) => {
  const user = await requireApiUser();
  const data = reviewSchema.parse(await req.json());

  const existing = await prisma.review.findUnique({ where: { userId: user.id }, select: { id: true } });
  if (existing) throw new ApiError(409, "You have already submitted a review. You can edit it instead.", "REVIEW_EXISTS");

  const review = await prisma.review.create({
    data: { ...data, userId: user.id, isApproved: false, status: "PENDING" },
  });
  await logActivity("REVIEW_SUBMITTED", user.id);
  return NextResponse.json({ review }, { status: 201 });
});
