import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { ApiError, route } from "@/lib/api";
import { requireApiUser } from "@/lib/session";
import { generateSchema } from "@/lib/validators";
import { getAIProvider, AIProviderError } from "@/lib/ai";
import { buildPrompt } from "@/lib/ai/prompts";
import { AI_NOT_CONFIGURED_MESSAGE, LIMIT_REACHED_MESSAGE } from "@/lib/config";
import { getUsage, utcDay } from "@/lib/usage";
import { TASK_BY_ID } from "@/lib/tasks";
import { truncate } from "@/lib/utils";
import { rateLimit } from "@/lib/rate-limit";
import { logActivity } from "@/lib/activity";

export const maxDuration = 60;

export const POST = route(async (req) => {
  const user = await requireApiUser();
  const input = generateSchema.parse(await req.json());

  if (!rateLimit(`generate:${user.id}`, 12, 60 * 1000)) {
    throw new ApiError(429, "You are generating very quickly. Please wait a moment and try again.", "RATE_LIMITED");
  }

  const provider = getAIProvider();
  if (!provider) throw new ApiError(503, AI_NOT_CONFIGURED_MESSAGE, "AI_NOT_CONFIGURED");

  const usageBefore = await getUsage(user.id);
  if (usageBefore.limitReached) throw new ApiError(429, LIMIT_REACHED_MESSAGE, "LIMIT_REACHED");

  const profile = await prisma.businessProfile.findUnique({ where: { userId: user.id } });

  const messages = buildPrompt({
    taskType: input.taskType,
    instructions: input.instructions,
    context: input.context,
    profile,
    refine: input.refine,
  });

  let output: string;
  try {
    output = await provider.generate(messages);
  } catch (err) {
    if (err instanceof AIProviderError) {
      throw new ApiError(502, "The AI service could not complete your request. Please try again in a moment.", "AI_ERROR");
    }
    throw err;
  }

  const task = TASK_BY_ID[input.taskType];
  const generation = await prisma.$transaction(async (tx) => {
    const created = await tx.generation.create({
      data: {
        userId: user.id,
        taskType: input.taskType,
        title: `${task.label}: ${truncate(input.instructions, 60)}`,
        instructions: input.instructions,
        context: input.context,
        output,
        model: provider.model,
      },
    });
    const day = utcDay();
    await tx.usageRecord.upsert({
      where: { userId_date: { userId: user.id, date: day } },
      create: { userId: user.id, date: day, count: 1 },
      update: { count: { increment: 1 } },
    });
    return created;
  });

  await logActivity("GENERATION_CREATED", user.id, input.taskType);
  const usage = await getUsage(user.id);
  return NextResponse.json({ generation, usage });
});
