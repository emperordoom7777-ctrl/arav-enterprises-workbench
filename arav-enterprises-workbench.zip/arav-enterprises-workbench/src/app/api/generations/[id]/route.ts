import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { ApiError, route } from "@/lib/api";
import { requireApiUser } from "@/lib/session";
import { saveSchema } from "@/lib/validators";

type Ctx = { params: { id: string } };

export const GET = route<Ctx>(async (_req, { params }) => {
  const user = await requireApiUser();
  const generation = await prisma.generation.findFirst({ where: { id: params.id, userId: user.id } });
  if (!generation) throw new ApiError(404, "We couldn't find that generation.", "NOT_FOUND");
  return NextResponse.json({ generation });
});

export const PATCH = route<Ctx>(async (req, { params }) => {
  const user = await requireApiUser();
  const { isSaved } = saveSchema.parse(await req.json());

  const result = await prisma.generation.updateMany({
    where: { id: params.id, userId: user.id },
    data: { isSaved },
  });
  if (result.count === 0) throw new ApiError(404, "We couldn't find that generation.", "NOT_FOUND");

  const generation = await prisma.generation.findFirst({ where: { id: params.id, userId: user.id } });
  return NextResponse.json({ generation });
});

export const DELETE = route<Ctx>(async (_req, { params }) => {
  const user = await requireApiUser();
  const result = await prisma.generation.deleteMany({ where: { id: params.id, userId: user.id } });
  if (result.count === 0) throw new ApiError(404, "We couldn't find that generation.", "NOT_FOUND");
  return NextResponse.json({ ok: true });
});
