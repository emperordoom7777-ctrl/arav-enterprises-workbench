import { NextResponse } from "next/server";
import type { Prisma } from "@prisma/client";
import { prisma } from "@/lib/db";
import { route } from "@/lib/api";
import { requireApiUser } from "@/lib/session";
import { generationQuerySchema } from "@/lib/validators";

const PAGE_SIZE = 20;

export const GET = route(async (req) => {
  const user = await requireApiUser();
  const params = Object.fromEntries(new URL(req.url).searchParams.entries());
  const query = generationQuerySchema.parse(params);

  const where: Prisma.GenerationWhereInput = {
    userId: user.id, // ownership: always scoped to the signed-in user
    ...(query.task ? { taskType: query.task } : {}),
    ...(query.saved === "1" ? { isSaved: true } : {}),
    ...(query.q
      ? {
          OR: [
            { title: { contains: query.q, mode: "insensitive" } },
            { output: { contains: query.q, mode: "insensitive" } },
            { instructions: { contains: query.q, mode: "insensitive" } },
          ],
        }
      : {}),
  };

  const [items, total] = await Promise.all([
    prisma.generation.findMany({
      where,
      orderBy: { createdAt: "desc" },
      skip: (query.page - 1) * PAGE_SIZE,
      take: PAGE_SIZE,
    }),
    prisma.generation.count({ where }),
  ]);

  return NextResponse.json({
    items,
    total,
    page: query.page,
    pageSize: PAGE_SIZE,
    hasMore: query.page * PAGE_SIZE < total,
  });
});
