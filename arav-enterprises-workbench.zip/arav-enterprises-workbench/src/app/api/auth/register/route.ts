import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { prisma } from "@/lib/db";
import { ApiError, route } from "@/lib/api";
import { registerSchema } from "@/lib/validators";
import { clientIp, rateLimit } from "@/lib/rate-limit";
import { logActivity } from "@/lib/activity";

export const POST = route(async (req) => {
  if (!rateLimit(`register:${clientIp(req)}`, 10, 60 * 60 * 1000)) {
    throw new ApiError(429, "Too many sign-up attempts. Please try again later.", "RATE_LIMITED");
  }

  const body = registerSchema.parse(await req.json());

  const existing = await prisma.user.findUnique({ where: { email: body.email }, select: { id: true } });
  if (existing) throw new ApiError(409, "An account with this email already exists. Try logging in.", "EMAIL_TAKEN");

  const passwordHash = await bcrypt.hash(body.password, 12);
  const user = await prisma.user.create({
    data: { name: body.name, email: body.email, passwordHash },
    select: { id: true },
  });

  await logActivity("USER_REGISTERED", user.id);
  return NextResponse.json({ ok: true }, { status: 201 });
});
