import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { route } from "@/lib/api";
import { requireApiUser } from "@/lib/session";
import { onboardingSchema } from "@/lib/validators";
import { logActivity } from "@/lib/activity";

/** Completes (or skips) onboarding. All fields are optional. */
export const POST = route(async (req) => {
  const user = await requireApiUser();
  const body = onboardingSchema.parse(await req.json().catch(() => ({})));

  const hasProfileData = body.businessName || body.industry || body.businessType;
  if (hasProfileData) {
    const existing = await prisma.businessProfile.findUnique({ where: { userId: user.id }, select: { id: true } });
    await prisma.businessProfile.upsert({
      where: { userId: user.id },
      create: {
        userId: user.id,
        businessName: body.businessName,
        industry: body.industry,
        businessType: body.businessType,
      },
      update: {
        ...(body.businessName ? { businessName: body.businessName } : {}),
        ...(body.industry ? { industry: body.industry } : {}),
        ...(body.businessType ? { businessType: body.businessType } : {}),
      },
    });
    if (!existing) await logActivity("PROFILE_CREATED", user.id);
  }

  await prisma.user.update({
    where: { id: user.id },
    data: { onboardingCompleted: true, aiGoals: body.goals },
  });

  return NextResponse.json({ ok: true });
});
