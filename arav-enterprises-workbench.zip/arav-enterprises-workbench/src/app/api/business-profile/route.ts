import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { route } from "@/lib/api";
import { requireApiUser } from "@/lib/session";
import { businessProfileSchema } from "@/lib/validators";
import { logActivity } from "@/lib/activity";

export const GET = route(async () => {
  const user = await requireApiUser();
  const profile = await prisma.businessProfile.findUnique({ where: { userId: user.id } });
  return NextResponse.json({ profile });
});

export const PUT = route(async (req) => {
  const user = await requireApiUser();
  const data = businessProfileSchema.parse(await req.json());

  const existing = await prisma.businessProfile.findUnique({ where: { userId: user.id }, select: { id: true } });
  const profile = await prisma.businessProfile.upsert({
    where: { userId: user.id },
    create: { userId: user.id, ...data },
    update: data,
  });
  if (!existing) await logActivity("PROFILE_CREATED", user.id);

  return NextResponse.json({ profile });
});
