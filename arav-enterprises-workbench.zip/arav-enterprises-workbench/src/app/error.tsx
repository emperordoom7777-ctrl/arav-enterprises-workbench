"use client";

export default function GlobalError({ reset }: { error: Error; reset: () => void }) {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center px-4 text-center">
      <h1 className="text-3xl font-semibold">Something went wrong</h1>
      <p className="mt-2 max-w-md text-muted">We could not load this page. Please try again. If the problem continues, come back in a few minutes.</p>
      <button type="button" onClick={reset} className="btn btn-primary mt-6">Try again</button>
    </main>
  );
}
