import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/session";
import { AuthShell } from "@/components/auth-shell";
import { LoginForm } from "./login-form";

export const metadata: Metadata = { title: "Log in" };

export default async function LoginPage() {
  const user = await getCurrentUser();
  if (user) redirect(user.onboardingCompleted ? "/dashboard" : "/onboarding");
  return (
    <AuthShell
      title="Welcome back"
      subtitle="Log in to your Workbench."
      footer={<>New here? <Link href="/signup" className="font-medium text-accent">Create a free account</Link></>}
    >
      <LoginForm />
    </AuthShell>
  );
}
