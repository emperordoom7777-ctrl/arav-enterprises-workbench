import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/session";
import { AuthShell } from "@/components/auth-shell";
import { SignupForm } from "./signup-form";

export const metadata: Metadata = { title: "Create your free account" };

export default async function SignupPage() {
  const user = await getCurrentUser();
  if (user) redirect(user.onboardingCompleted ? "/dashboard" : "/onboarding");
  return (
    <AuthShell
      title="Create your free account"
      subtitle="Version 1.0 is free. No payment details needed."
      footer={<>Already have an account? <Link href="/login" className="font-medium text-accent">Log in</Link></>}
    >
      <SignupForm />
    </AuthShell>
  );
}
