"use client";

import { useState } from "react";
import { signIn } from "next-auth/react";
import { useRouter } from "next/navigation";
import { api, errorMessage } from "@/lib/client";
import { registerSchema } from "@/lib/validators";
import { ErrorNotice, Field, Spinner } from "@/components/ui";

export function SignupForm() {
  const router = useRouter();
  const [form, setForm] = useState({ name: "", email: "", password: "" });
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const set = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setForm((f) => ({ ...f, [k]: e.target.value }));

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");

    const parsed = registerSchema.safeParse(form);
    if (!parsed.success) {
      const errs: Record<string, string> = {};
      for (const issue of parsed.error.issues) {
        const key = String(issue.path[0]);
        if (!errs[key]) errs[key] = issue.message;
      }
      setFieldErrors(errs);
      return;
    }
    setFieldErrors({});
    setBusy(true);
    try {
      await api("/api/auth/register", { method: "POST", json: parsed.data });
      const res = await signIn("credentials", { email: parsed.data.email, password: parsed.data.password, redirect: false });
      if (!res || res.error) {
        router.push("/login");
        return;
      }
      router.push("/onboarding");
      router.refresh();
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  }

  return (
    <form onSubmit={onSubmit} className="space-y-4" noValidate>
      {error && <ErrorNotice message={error} />}
      <Field label="Full name" htmlFor="name" error={fieldErrors.name}>
        <input id="name" autoComplete="name" className="input" value={form.name} onChange={set("name")} />
      </Field>
      <Field label="Email" htmlFor="email" error={fieldErrors.email}>
        <input id="email" type="email" autoComplete="email" className="input" value={form.email} onChange={set("email")} />
      </Field>
      <Field label="Password" htmlFor="password" error={fieldErrors.password} hint="At least 8 characters, with a letter and a number.">
        <input id="password" type="password" autoComplete="new-password" className="input" value={form.password} onChange={set("password")} />
      </Field>
      <button type="submit" className="btn btn-primary w-full" disabled={busy}>
        {busy && <Spinner />} Create account
      </button>
    </form>
  );
}
