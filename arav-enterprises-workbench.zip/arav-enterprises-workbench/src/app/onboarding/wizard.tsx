"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Check } from "lucide-react";
import { api, errorMessage } from "@/lib/client";
import { AI_GOALS, BUSINESS_TYPES, INDUSTRIES } from "@/lib/tasks";
import { ErrorNotice, Field, Spinner } from "@/components/ui";
import { cn } from "@/lib/utils";

export function OnboardingWizard({ firstName }: { firstName: string }) {
  const router = useRouter();
  const [step, setStep] = useState(1);
  const [businessName, setBusinessName] = useState("");
  const [industry, setIndustry] = useState("");
  const [businessType, setBusinessType] = useState("");
  const [goals, setGoals] = useState<string[]>([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  async function finish(skip: boolean) {
    setBusy(true);
    setError("");
    try {
      await api("/api/onboarding", {
        method: "POST",
        json: skip ? { goals: [] } : { businessName, industry, businessType, goals },
      });
      router.push("/dashboard");
      router.refresh();
    } catch (err) {
      setError(errorMessage(err));
      setBusy(false);
    }
  }

  const toggleGoal = (g: string) => setGoals((cur) => (cur.includes(g) ? cur.filter((x) => x !== g) : [...cur, g]));

  return (
    <div className="card w-full max-w-lg p-6 sm:p-8">
      <div className="mb-6 flex gap-1.5" aria-label={`Step ${step} of 3`}>
        {[1, 2, 3].map((n) => (
          <span key={n} className={cn("h-1.5 flex-1 rounded-full", n <= step ? "bg-accent" : "bg-sunken")} />
        ))}
      </div>

      {error && <div className="mb-4"><ErrorNotice message={error} /></div>}

      {step === 1 && (
        <div>
          <h1 className="text-2xl font-semibold">Welcome to Arav Enterprises Workbench, {firstName}.</h1>
          <p className="mt-2 text-sm leading-relaxed text-muted">
            Two quick questions help Workbench write in your voice. Both are optional, and you can change your answers later.
          </p>
          <div className="mt-8 flex flex-col-reverse gap-2 sm:flex-row sm:justify-between">
            <button type="button" className="btn btn-ghost" onClick={() => finish(true)} disabled={busy}>
              {busy && <Spinner />} Skip setup
            </button>
            <button type="button" className="btn btn-primary" onClick={() => setStep(2)}>Continue</button>
          </div>
        </div>
      )}

      {step === 2 && (
        <div>
          <h1 className="text-2xl font-semibold">Tell us about your business</h1>
          <div className="mt-6 space-y-4">
            <Field label="Business name" htmlFor="bn">
              <input id="bn" className="input" maxLength={120} value={businessName} onChange={(e) => setBusinessName(e.target.value)} />
            </Field>
            <Field label="Industry" htmlFor="ind">
              <select id="ind" className="input" value={industry} onChange={(e) => setIndustry(e.target.value)}>
                <option value="">Select an industry</option>
                {INDUSTRIES.map((i) => <option key={i}>{i}</option>)}
              </select>
            </Field>
            <Field label="Type of business" htmlFor="bt">
              <select id="bt" className="input" value={businessType} onChange={(e) => setBusinessType(e.target.value)}>
                <option value="">Select a type</option>
                {BUSINESS_TYPES.map((i) => <option key={i}>{i}</option>)}
              </select>
            </Field>
          </div>
          <div className="mt-8 flex flex-col-reverse gap-2 sm:flex-row sm:justify-between">
            <button type="button" className="btn btn-ghost" onClick={() => setStep(3)}>Skip this step</button>
            <button type="button" className="btn btn-primary" onClick={() => setStep(3)}>Continue</button>
          </div>
        </div>
      )}

      {step === 3 && (
        <div>
          <h1 className="text-2xl font-semibold">What do you want to use AI for?</h1>
          <p className="mt-2 text-sm text-muted">Choose as many as you like.</p>
          <div className="mt-5 grid gap-2 sm:grid-cols-2">
            {AI_GOALS.map((g) => {
              const on = goals.includes(g);
              return (
                <button
                  key={g}
                  type="button"
                  role="checkbox"
                  aria-checked={on}
                  onClick={() => toggleGoal(g)}
                  className={cn(
                    "flex items-center justify-between gap-2 rounded-xl border px-4 py-3 text-left text-sm transition-colors",
                    on ? "border-accent bg-accent-soft text-accent" : "border-line hover:bg-sunken",
                  )}
                >
                  {g}
                  {on && <Check className="h-4 w-4" aria-hidden />}
                </button>
              );
            })}
          </div>
          <div className="mt-8 flex flex-col-reverse gap-2 sm:flex-row sm:justify-between">
            <button type="button" className="btn btn-ghost" onClick={() => setStep(2)} disabled={busy}>Back</button>
            <button type="button" className="btn btn-primary" onClick={() => finish(false)} disabled={busy}>
              {busy && <Spinner />} Go to my dashboard
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
