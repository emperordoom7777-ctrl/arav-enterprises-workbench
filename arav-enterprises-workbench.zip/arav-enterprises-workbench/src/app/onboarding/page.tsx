import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { requireUser } from "@/lib/session";
import { Logo } from "@/components/logo";
import { OnboardingWizard } from "./wizard";

export const metadata: Metadata = { title: "Welcome" };

export default async function OnboardingPage() {
  const user = await requireUser();
  if (user.onboardingCompleted) redirect("/dashboard");
  return (
    <main className="flex min-h-screen flex-col items-center px-4 py-10">
      <Logo className="mb-8" />
      <OnboardingWizard firstName={user.name.split(" ")[0] ?? user.name} />
    </main>
  );
}
