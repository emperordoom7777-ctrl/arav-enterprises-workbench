"use client";

import { useState } from "react";
import { Pencil, Trash2 } from "lucide-react";
import { api, errorMessage } from "@/lib/client";
import { reviewSchema } from "@/lib/validators";
import { ConfirmDialog, ErrorNotice, Field, Spinner, StarInput, Stars } from "@/components/ui";
import { useToast } from "@/components/toast";

type Status = "PENDING" | "APPROVED" | "REJECTED";
interface ReviewData { rating: number; title: string; message: string; businessName: string; status: Status }

const STATUS_TEXT: Record<Status, { label: string; text: string; cls: string }> = {
  PENDING: { label: "Pending", text: "Your review is waiting for approval.", cls: "badge-warn" },
  APPROVED: { label: "Approved", text: "Your review is publicly visible.", cls: "badge-success" },
  REJECTED: { label: "Not published", text: "Your review was not approved for public display. You can edit it and submit it again.", cls: "badge-danger" },
};

export function ReviewPanel({ initial }: { initial: ReviewData | null }) {
  const { toast } = useToast();
  const [review, setReview] = useState<ReviewData | null>(initial);
  const [editing, setEditing] = useState(initial === null);
  const [form, setForm] = useState({ rating: initial?.rating ?? 0, title: initial?.title ?? "", message: initial?.message ?? "", businessName: initial?.businessName ?? "" });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    const parsed = reviewSchema.safeParse(form);
    if (!parsed.success) {
      const errs: Record<string, string> = {};
      for (const i of parsed.error.issues) errs[String(i.path[0])] ??= i.message;
      setErrors(errs);
      return;
    }
    setErrors({});
    setBusy(true);
    try {
      const isNew = review === null;
      const data = await api<{ review: { rating: number; title: string; message: string; businessName: string | null; status: Status } }>(
        isNew ? "/api/reviews" : "/api/reviews/me",
        { method: isNew ? "POST" : "PUT", json: form },
      );
      setReview({ ...data.review, businessName: data.review.businessName ?? "" });
      setEditing(false);
      toast(isNew ? "Thanks! Your review was submitted for approval." : "Review updated and sent for approval.");
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  }

  async function remove() {
    setBusy(true);
    try {
      await api("/api/reviews/me", { method: "DELETE" });
      setReview(null);
      setForm({ rating: 0, title: "", message: "", businessName: "" });
      setEditing(true);
      setConfirmDelete(false);
      toast("Review deleted");
    } catch (err) {
      toast(errorMessage(err), "error");
    } finally {
      setBusy(false);
    }
  }

  if (review && !editing) {
    const s = STATUS_TEXT[review.status];
    return (
      <div className="card p-5 sm:p-6">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <span className={`badge ${s.cls}`}>{s.label}</span>
          <div className="flex gap-2">
            <button type="button" className="btn btn-secondary btn-sm" onClick={() => setEditing(true)}><Pencil className="h-3.5 w-3.5" /> Edit</button>
            <button type="button" className="btn btn-secondary btn-sm text-danger" onClick={() => setConfirmDelete(true)}><Trash2 className="h-3.5 w-3.5" /> Delete</button>
          </div>
        </div>
        <p className="mt-3 text-sm text-muted">{s.text}</p>
        <div className="mt-5 border-t border-line pt-5">
          <Stars value={review.rating} />
          <h2 className="mt-2 text-lg font-semibold">{review.title}</h2>
          {review.businessName && <p className="text-sm text-muted">{review.businessName}</p>}
          <p className="mt-3 whitespace-pre-wrap break-words text-[15px] leading-relaxed">{review.message}</p>
        </div>
        <ConfirmDialog open={confirmDelete} title="Delete your review?" message="Your review will be removed permanently. You can write a new one afterwards." busy={busy} onConfirm={remove} onCancel={() => setConfirmDelete(false)} />
      </div>
    );
  }

  return (
    <form onSubmit={submit} className="card max-w-2xl space-y-5 p-5 sm:p-6" noValidate>
      <h2 className="font-semibold">{review ? "Edit your review" : "Write a review"}</h2>
      {error && <ErrorNotice message={error} />}
      <Field label="Rating" error={errors.rating}>
        <StarInput value={form.rating} onChange={(rating) => setForm((f) => ({ ...f, rating }))} />
      </Field>
      <Field label="Review title" htmlFor="rtitle" error={errors.title}>
        <input id="rtitle" className="input" maxLength={100} value={form.title} onChange={(e) => setForm((f) => ({ ...f, title: e.target.value }))} />
      </Field>
      <Field label="Review message" htmlFor="rmessage" error={errors.message}>
        <textarea id="rmessage" className="input min-h-[140px]" maxLength={1500} value={form.message} onChange={(e) => setForm((f) => ({ ...f, message: e.target.value }))} />
      </Field>
      <Field label="Business name (optional)" htmlFor="rbusiness" hint="Shown next to your review if it is approved.">
        <input id="rbusiness" className="input" maxLength={120} value={form.businessName} onChange={(e) => setForm((f) => ({ ...f, businessName: e.target.value }))} />
      </Field>
      <p className="text-xs text-muted">Reviews are checked by an administrator before they appear on the website.</p>
      <div className="flex justify-end gap-2">
        {review && <button type="button" className="btn btn-secondary" onClick={() => setEditing(false)} disabled={busy}>Cancel</button>}
        <button type="submit" className="btn btn-primary" disabled={busy}>{busy && <Spinner />} {review ? "Save changes" : "Submit review"}</button>
      </div>
    </form>
  );
}
