import type { Metadata } from "next";
import { prisma } from "@/lib/db";
import { requireUser } from "@/lib/session";
import { ReviewPanel } from "./review-panel";

export const metadata: Metadata = { title: "Reviews" };
export const dynamic = "force-dynamic";

export default async function ReviewsPage() {
  const user = await requireUser();
  const review = await prisma.review.findUnique({ where: { userId: user.id } });
  return (
    <div className="space-y-8">
      <div>
        <h1 className="page-title">Reviews</h1>
        <p className="mt-1.5 max-w-2xl text-muted">Share your experience with Arav Enterprises Workbench. Your feedback helps us improve.</p>
      </div>
      <ReviewPanel
        initial={review ? { rating: review.rating, title: review.title, message: review.message, businessName: review.businessName ?? "", status: review.status } : null}
      />
    </div>
  );
}
