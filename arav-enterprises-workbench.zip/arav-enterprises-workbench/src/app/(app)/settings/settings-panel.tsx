"use client";

import Link from "next/link";
import { useState } from "react";
import { signOut, useSession } from "next-auth/react";
import { Monitor, Moon, Sun } from "lucide-react";
import { api, errorMessage } from "@/lib/client";
import { useTheme, type ThemePreference } from "@/components/theme";
import { useToast } from "@/components/toast";
import { ErrorNotice, Field, Modal, Spinner } from "@/components/ui";
import { cn } from "@/lib/utils";

const themes: { id: ThemePreference; label: string; icon: typeof Sun }[] = [
  { id: "light", label: "Light", icon: Sun },
  { id: "dark", label: "Dark", icon: Moon },
  { id: "system", label: "System", icon: Monitor },
];

export function SettingsPanel({ name: initialName, email }: { name: string; email: string }) {
  const { toast } = useToast();
  const { update } = useSession();
  const { theme, setTheme } = useTheme();
  const [name, setName] = useState(initialName);
  const [saving, setSaving] = useState(false);
  const [nameError, setNameError] = useState("");
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [confirmText, setConfirmText] = useState("");
  const [deleting, setDeleting] = useState(false);
  const [deleteError, setDeleteError] = useState("");

  async function saveName(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setNameError("");
    try {
      const data = await api<{ user: { name: string } }>("/api/account", { method: "PATCH", json: { name } });
      await update({ name: data.user.name });
      toast("Account updated");
    } catch (err) {
      setNameError(errorMessage(err));
    } finally {
      setSaving(false);
    }
  }

  async function deleteAccount() {
    setDeleting(true);
    setDeleteError("");
    try {
      await api("/api/account", { method: "DELETE", json: { confirm: confirmText } });
      await signOut({ callbackUrl: "/" });
    } catch (err) {
      setDeleteError(errorMessage(err));
      setDeleting(false);
    }
  }

  return (
    <div className="max-w-2xl space-y-6">
      <section className="card p-5 sm:p-6">
        <h2 className="font-semibold">Account</h2>
        <form onSubmit={saveName} className="mt-4 space-y-4">
          {nameError && <ErrorNotice message={nameError} />}
          <Field label="Name" htmlFor="name"><input id="name" className="input" value={name} maxLength={80} onChange={(e) => setName(e.target.value)} /></Field>
          <Field label="Email" htmlFor="email" hint="Your email is used to log in and cannot be changed here."><input id="email" className="input opacity-70" value={email} readOnly /></Field>
          <button type="submit" className="btn btn-primary" disabled={saving || name.trim().length < 2 || name === initialName}>{saving && <Spinner />} Save changes</button>
        </form>
      </section>

      <section className="card p-5 sm:p-6">
        <h2 className="font-semibold">Business</h2>
        <p className="mt-1 text-sm text-muted">Manage the details that shape your generated content.</p>
        <Link href="/business-profile" className="btn btn-secondary mt-4">Open Business Profile</Link>
      </section>

      <section className="card p-5 sm:p-6">
        <h2 className="font-semibold">Appearance</h2>
        <div className="mt-4 grid grid-cols-3 gap-2" role="radiogroup" aria-label="Theme">
          {themes.map((t) => (
            <button
              key={t.id}
              type="button"
              role="radio"
              aria-checked={theme === t.id}
              onClick={() => setTheme(t.id)}
              className={cn("flex flex-col items-center gap-2 rounded-xl border px-3 py-4 text-sm transition-colors", theme === t.id ? "border-accent bg-accent-soft text-accent" : "border-line hover:bg-sunken")}
            >
              <t.icon className="h-5 w-5" aria-hidden /> {t.label}
            </button>
          ))}
        </div>
      </section>

      <section className="card border-danger/30 p-5 sm:p-6">
        <h2 className="font-semibold text-danger">Account management</h2>
        <p className="mt-1 text-sm text-muted">Deleting your account permanently removes your profile, generations, saved content and review. This cannot be undone.</p>
        <button type="button" className="btn btn-danger mt-4" onClick={() => setDeleteOpen(true)}>Delete account</button>
      </section>

      <Modal open={deleteOpen} onClose={() => !deleting && setDeleteOpen(false)} title="Delete your account?">
        <p className="text-sm text-muted">Type <strong className="text-ink">DELETE</strong> to confirm. All of your data will be removed immediately.</p>
        {deleteError && <div className="mt-3"><ErrorNotice message={deleteError} /></div>}
        <input className="input mt-4" aria-label="Type DELETE to confirm" value={confirmText} onChange={(e) => setConfirmText(e.target.value)} autoComplete="off" />
        <div className="mt-5 flex justify-end gap-2">
          <button type="button" className="btn btn-secondary" onClick={() => setDeleteOpen(false)} disabled={deleting}>Cancel</button>
          <button type="button" className="btn btn-danger" onClick={deleteAccount} disabled={deleting || confirmText !== "DELETE"}>{deleting && <Spinner />} Delete my account</button>
        </div>
      </Modal>
    </div>
  );
}
