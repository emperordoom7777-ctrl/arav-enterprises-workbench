import type { Metadata } from "next";
import { requireUser } from "@/lib/session";
import { SettingsPanel } from "./settings-panel";

export const metadata: Metadata = { title: "Settings" };

export default async function SettingsPage() {
  const user = await requireUser();
  return (
    <div className="space-y-8">
      <h1 className="page-title">Settings</h1>
      <SettingsPanel name={user.name} email={user.email} />
    </div>
  );
}
