import type { Metadata } from "next";
import { requireUser } from "@/lib/session";
import { getUsage } from "@/lib/usage";
import { StatCard } from "@/components/stat-card";
import { ProgressBar } from "@/components/ui";
import { LIMIT_REACHED_MESSAGE } from "@/lib/config";

export const metadata: Metadata = { title: "Usage" };
export const dynamic = "force-dynamic";

export default async function UsagePage() {
  const user = await requireUser();
  const u = await getUsage(user.id);

  return (
    <div className="space-y-8">
      <div>
        <h1 className="page-title">Usage</h1>
        <p className="mt-1.5 text-muted">Workbench is free. Limits keep it fast for everyone and reset automatically.</p>
      </div>

      {u.limitReached && (
        <div role="alert" className="rounded-xl border border-warn/40 bg-warn/10 px-4 py-3 text-sm">{LIMIT_REACHED_MESSAGE}</div>
      )}

      <section className="card p-6">
        <div className="flex flex-wrap items-end justify-between gap-2">
          <div>
            <p className="text-sm text-muted">Monthly generations used</p>
            <p className="mt-1 font-display text-4xl font-semibold tabular-nums">{u.month}<span className="text-xl text-muted"> / {u.monthlyLimit}</span></p>
          </div>
          <p className="text-sm text-muted">{u.remainingMonth} remaining this month</p>
        </div>
        <div className="mt-4"><ProgressBar value={u.month} max={u.monthlyLimit} /></div>
      </section>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Generations today" value={u.day} hint={`Daily limit: ${u.dailyLimit}`} />
        <StatCard label="Remaining today" value={u.remainingDay} />
        <StatCard label="Remaining this month" value={u.remainingMonth} hint={`Monthly limit: ${u.monthlyLimit}`} />
        <StatCard label="All-time generations" value={u.total} />
      </div>
      <p className="text-xs text-muted">Counts use UTC dates. Deleting a generation does not return its usage.</p>
    </div>
  );
}
