"use client";

import { useState } from "react";
import { Bookmark, BookmarkCheck, Copy, RefreshCw, Sparkles, Wand2, Minimize2, Maximize2 } from "lucide-react";
import { TASKS, TASK_BY_ID } from "@/lib/tasks";
import type { TaskType } from "@prisma/client";
import type { UsageSummary } from "@/lib/usage";
import { api, copyText, errorMessage } from "@/lib/client";
import { useToast } from "@/components/toast";
import { ErrorNotice, Field, Spinner } from "@/components/ui";
import { cn } from "@/lib/utils";

type Action = "generate" | "regenerate" | "improve" | "shorten" | "expand";
interface Result { id: string; output: string; isSaved: boolean; taskType: TaskType }

export function Workspace({ initialUsage, aiConfigured }: { initialUsage: UsageSummary; aiConfigured: boolean }) {
  const { toast } = useToast();
  const [task, setTask] = useState<TaskType>("CUSTOMER_REPLY");
  const [instructions, setInstructions] = useState("");
  const [context, setContext] = useState("");
  const [result, setResult] = useState<Result | null>(null);
  const [usage, setUsage] = useState(initialUsage);
  const [busy, setBusy] = useState<Action | null>(null);
  const [error, setError] = useState("");

  const def = TASK_BY_ID[task];
  const limitReached = usage.limitReached;

  async function run(action: Action) {
    setError("");
    if (instructions.trim().length < 3) {
      setError("Tell the assistant what you need first.");
      return;
    }
    setBusy(action);
    try {
      const refine = action === "improve" || action === "shorten" || action === "expand";
      const data = await api<{ generation: { id: string; output: string; isSaved: boolean; taskType: TaskType }; usage: UsageSummary }>(
        "/api/generate",
        {
          method: "POST",
          json: {
            taskType: task,
            instructions,
            context: context || undefined,
            ...(refine && result ? { refine: { action, previousOutput: result.output } } : {}),
          },
        },
      );
      setResult({ id: data.generation.id, output: data.generation.output, isSaved: data.generation.isSaved, taskType: data.generation.taskType });
      setUsage(data.usage);
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusy(null);
    }
  }

  async function copy() {
    if (!result) return;
    const ok = await copyText(result.output);
    toast(ok ? "Copied to clipboard" : "Could not copy. Select the text and copy it manually.", ok ? "success" : "error");
  }

  async function toggleSave() {
    if (!result) return;
    try {
      const next = !result.isSaved;
      await api(`/api/generations/${result.id}`, { method: "PATCH", json: { isSaved: next } });
      setResult({ ...result, isSaved: next });
      toast(next ? "Saved" : "Removed from saved content");
    } catch (err) {
      toast(errorMessage(err), "error");
    }
  }

  const refineBtn = (action: Exclude<Action, "generate" | "regenerate">, label: string, Icon: typeof Wand2) => (
    <button type="button" className="btn btn-secondary btn-sm" onClick={() => run(action)} disabled={busy !== null || limitReached}>
      {busy === action ? <Spinner className="h-3.5 w-3.5" /> : <Icon className="h-3.5 w-3.5" />} {label}
    </button>
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="page-title">AI Workspace</h1>
          <p className="mt-1.5 text-muted">Choose a task, describe what you need, and review the draft.</p>
        </div>
        <p className="text-sm text-muted tabular-nums">{usage.remaining} generation{usage.remaining === 1 ? "" : "s"} left today</p>
      </div>

      {!aiConfigured && (
        <div role="alert" className="rounded-xl border border-warn/40 bg-warn/10 px-4 py-3 text-sm">
          AI generation is currently not configured. Please contact the administrator.
        </div>
      )}
      {limitReached && aiConfigured && (
        <div role="alert" className="rounded-xl border border-warn/40 bg-warn/10 px-4 py-3 text-sm">
          You have reached your current free usage limit. Please try again later.
        </div>
      )}

      <div className="grid gap-6 lg:grid-cols-[minmax(0,26rem)_minmax(0,1fr)]">
        {/* Left: inputs */}
        <section className="card space-y-5 p-5">
          <Field label="Task" htmlFor="task" hint={def.description}>
            <select id="task" className="input" value={task} onChange={(e) => setTask(e.target.value as TaskType)}>
              {TASKS.map((t) => <option key={t.id} value={t.id}>{t.label}</option>)}
            </select>
          </Field>

          <div className="hidden flex-wrap gap-1.5 sm:flex" role="group" aria-label="Quick task picker">
            {TASKS.map((t) => (
              <button
                key={t.id}
                type="button"
                onClick={() => setTask(t.id)}
                aria-pressed={task === t.id}
                className={cn("rounded-full border px-3 py-1 text-xs transition-colors", task === t.id ? "border-accent bg-accent-soft text-accent" : "border-line text-muted hover:bg-sunken")}
              >
                {t.label}
              </button>
            ))}
          </div>

          <Field label="Instructions" htmlFor="instructions">
            <textarea id="instructions" className="input min-h-[150px] resize-y" maxLength={4000} placeholder={def.placeholder} value={instructions} onChange={(e) => setInstructions(e.target.value)} />
          </Field>
          <Field label="Additional context (optional)" htmlFor="context" hint="Facts, prices, deadlines or anything the draft must include.">
            <textarea id="context" className="input min-h-[90px] resize-y" maxLength={4000} value={context} onChange={(e) => setContext(e.target.value)} />
          </Field>

          <button type="button" className="btn btn-primary w-full" onClick={() => run("generate")} disabled={busy !== null || limitReached || !aiConfigured}>
            {busy === "generate" ? <Spinner /> : <Sparkles className="h-4 w-4" />} Generate
          </button>
        </section>

        {/* Right: output */}
        <section className="card flex min-h-[320px] flex-col">
          {error && <div className="p-4 pb-0"><ErrorNotice message={error} /></div>}

          {busy ? (
            <div className="flex-1 space-y-3 p-6" aria-busy="true" aria-live="polite">
              <p className="text-sm text-muted">Writing your draft…</p>
              <div className="skeleton h-4 w-11/12" /><div className="skeleton h-4 w-full" /><div className="skeleton h-4 w-9/12" /><div className="skeleton h-4 w-10/12" />
            </div>
          ) : result ? (
            <>
              <div className="flex flex-wrap items-center gap-2 border-b border-line px-4 py-3">
                <span className="badge badge-accent mr-auto">{TASK_BY_ID[result.taskType].label}</span>
                <button type="button" className="btn btn-secondary btn-sm" onClick={copy}><Copy className="h-3.5 w-3.5" /> Copy</button>
                <button type="button" className="btn btn-secondary btn-sm" onClick={toggleSave}>
                  {result.isSaved ? <BookmarkCheck className="h-3.5 w-3.5 text-accent" /> : <Bookmark className="h-3.5 w-3.5" />} {result.isSaved ? "Saved" : "Save"}
                </button>
              </div>
              <div className="flex-1 whitespace-pre-wrap break-words p-5 text-[15px] leading-relaxed">{result.output}</div>
              <div className="flex flex-wrap gap-2 border-t border-line px-4 py-3">
                <button type="button" className="btn btn-secondary btn-sm" onClick={() => run("regenerate")} disabled={limitReached}><RefreshCw className="h-3.5 w-3.5" /> Regenerate</button>
                {refineBtn("improve", "Improve", Wand2)}
                {refineBtn("shorten", "Shorten", Minimize2)}
                {refineBtn("expand", "Expand", Maximize2)}
              </div>
              <p className="px-4 pb-3 text-xs text-muted">Each action counts as one generation. Check names, prices and dates before you use a draft.</p>
            </>
          ) : (
            <div className="flex flex-1 flex-col items-center justify-center px-6 py-12 text-center">
              <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-accent-soft text-accent"><Sparkles className="h-6 w-6" /></div>
              <h2 className="text-lg font-semibold">Start your first AI task.</h2>
              <p className="mt-1.5 max-w-sm text-sm text-muted">Your generated content will appear here.</p>
            </div>
          )}
        </section>
      </div>
    </div>
  );
}
