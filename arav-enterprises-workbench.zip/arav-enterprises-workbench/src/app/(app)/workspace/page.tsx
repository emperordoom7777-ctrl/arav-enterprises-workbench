import type { Metadata } from "next";
import { requireUser } from "@/lib/session";
import { getUsage } from "@/lib/usage";
import { appConfig } from "@/lib/config";
import { Workspace } from "./workspace";

export const metadata: Metadata = { title: "AI Workspace" };
export const dynamic = "force-dynamic";

export default async function WorkspacePage() {
  const user = await requireUser();
  const usage = await getUsage(user.id);
  return <Workspace initialUsage={usage} aiConfigured={appConfig.ai.isConfigured} />;
}
