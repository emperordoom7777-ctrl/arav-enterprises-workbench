import type { Metadata } from "next";
import Link from "next/link";
import { Sparkles, Building2, History as HistoryIcon, ArrowRight } from "lucide-react";
import { prisma } from "@/lib/db";
import { requireUser } from "@/lib/session";
import { getUsage } from "@/lib/usage";
import { TASK_BY_ID } from "@/lib/tasks";
import { StatCard } from "@/components/stat-card";
import { EmptyState, ProgressBar } from "@/components/ui";
import { timeAgo, truncate } from "@/lib/utils";

export const metadata: Metadata = { title: "Dashboard" };
export const dynamic = "force-dynamic";

const activityLabel: Record<string, string> = {
  USER_REGISTERED: "Created your account",
  PROFILE_CREATED: "Created your business profile",
  GENERATION_CREATED: "Generated content",
  REVIEW_SUBMITTED: "Submitted a review",
  REVIEW_MODERATED: "Review updated by moderator",
  ACCOUNT_DELETED: "Account deleted",
};

export default async function DashboardPage() {
  const user = await requireUser();
  const [usage, savedCount, recent, activity, profile] = await Promise.all([
    getUsage(user.id),
    prisma.generation.count({ where: { userId: user.id, isSaved: true } }),
    prisma.generation.findMany({ where: { userId: user.id }, orderBy: { createdAt: "desc" }, take: 5 }),
    prisma.activity.findMany({ where: { userId: user.id }, orderBy: { createdAt: "desc" }, take: 6 }),
    prisma.businessProfile.findUnique({ where: { userId: user.id }, select: { businessName: true } }),
  ]);

  return (
    <div className="space-y-8">
      <div>
        <h1 className="page-title">Welcome, {user.name.split(" ")[0]}</h1>
        <p className="mt-1.5 text-muted">Here is what is happening in your workspace.</p>
      </div>

      <div className="flex flex-col gap-3 sm:flex-row">
        <Link href="/workspace" className="btn btn-primary"><Sparkles className="h-4 w-4" /> New AI Generation</Link>
        <Link href="/business-profile" className="btn btn-secondary"><Building2 className="h-4 w-4" /> {profile?.businessName ? "Edit Business Profile" : "Set up Business Profile"}</Link>
        <Link href="/history" className="btn btn-secondary"><HistoryIcon className="h-4 w-4" /> View History</Link>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Total AI generations" value={usage.total} />
        <StatCard label="Generations this month" value={usage.month} />
        <StatCard label="Saved content" value={savedCount} />
        <div className="card p-5">
          <p className="text-sm text-muted">Current usage</p>
          <p className="mt-2 font-display text-3xl font-semibold tabular-nums">{usage.month}<span className="text-lg text-muted"> / {usage.monthlyLimit}</span></p>
          <div className="mt-3"><ProgressBar value={usage.month} max={usage.monthlyLimit} /></div>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-[1.4fr_1fr]">
        <section className="card">
          <div className="flex items-center justify-between border-b border-line px-5 py-4">
            <h2 className="font-semibold">Recent generations</h2>
            <Link href="/history" className="inline-flex items-center gap-1 text-sm text-accent">View all <ArrowRight className="h-3.5 w-3.5" /></Link>
          </div>
          {recent.length === 0 ? (
            <EmptyState icon={Sparkles} title="No generations yet." description="Start your first AI task." action={<Link href="/workspace" className="btn btn-primary">Open AI Workspace</Link>} />
          ) : (
            <ul className="divide-y divide-line">
              {recent.map((g) => (
                <li key={g.id}>
                  <Link href={`/history?open=${g.id}`} className="block px-5 py-4 transition-colors hover:bg-sunken/60">
                    <div className="flex items-center justify-between gap-3">
                      <span className="badge badge-accent">{TASK_BY_ID[g.taskType].label}</span>
                      <span className="text-xs text-muted">{timeAgo(g.createdAt)}</span>
                    </div>
                    <p className="mt-2 text-sm text-muted">{truncate(g.output, 140)}</p>
                  </Link>
                </li>
              ))}
            </ul>
          )}
        </section>

        <section className="card">
          <div className="border-b border-line px-5 py-4"><h2 className="font-semibold">Recent activity</h2></div>
          {activity.length === 0 ? (
            <p className="px-5 py-8 text-sm text-muted">Your activity will appear here.</p>
          ) : (
            <ul className="divide-y divide-line">
              {activity.map((a) => (
                <li key={a.id} className="flex items-center justify-between gap-3 px-5 py-3 text-sm">
                  <span>{activityLabel[a.type] ?? a.type}{a.type === "GENERATION_CREATED" && a.note ? ` · ${TASK_BY_ID[a.note as keyof typeof TASK_BY_ID]?.label ?? ""}` : ""}</span>
                  <span className="shrink-0 text-xs text-muted">{timeAgo(a.createdAt)}</span>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>
    </div>
  );
}
