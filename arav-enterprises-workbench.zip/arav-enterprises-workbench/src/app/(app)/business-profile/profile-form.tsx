"use client";

import { useState } from "react";
import { api, errorMessage } from "@/lib/client";
import { BRAND_TONES, BUSINESS_TYPES, INDUSTRIES } from "@/lib/tasks";
import { ErrorNotice, Field, Spinner } from "@/components/ui";
import { useToast } from "@/components/toast";

type Values = {
  businessName: string; industry: string; businessType: string; description: string; productsServices: string;
  targetCustomers: string; brandTone: string; writingStyle: string; website: string; additionalContext: string;
};

export function ProfileForm({ initial }: { initial: Values }) {
  const { toast } = useToast();
  const [v, setV] = useState<Values>(initial);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  const set = (k: keyof Values) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) =>
    setV((cur) => ({ ...cur, [k]: e.target.value }));

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError("");
    try {
      await api("/api/business-profile", { method: "PUT", json: v });
      toast("Business profile saved");
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  }

  const withCurrent = (list: string[], current: string) => (current && !list.includes(current) ? [current, ...list] : list);

  return (
    <form onSubmit={onSubmit} className="space-y-6">
      {error && <ErrorNotice message={error} />}

      <section className="card space-y-5 p-5 sm:p-6">
        <h2 className="font-semibold">About your business</h2>
        <div className="grid gap-5 sm:grid-cols-2">
          <Field label="Business name" htmlFor="businessName"><input id="businessName" className="input" maxLength={120} value={v.businessName} onChange={set("businessName")} /></Field>
          <Field label="Website" htmlFor="website"><input id="website" className="input" placeholder="example.com" maxLength={200} value={v.website} onChange={set("website")} /></Field>
          <Field label="Industry" htmlFor="industry">
            <select id="industry" className="input" value={v.industry} onChange={set("industry")}>
              <option value="">Select an industry</option>
              {withCurrent(INDUSTRIES, v.industry).map((i) => <option key={i}>{i}</option>)}
            </select>
          </Field>
          <Field label="Type of business" htmlFor="businessType">
            <select id="businessType" className="input" value={v.businessType} onChange={set("businessType")}>
              <option value="">Select a type</option>
              {withCurrent(BUSINESS_TYPES, v.businessType).map((i) => <option key={i}>{i}</option>)}
            </select>
          </Field>
        </div>
        <Field label="Business description" htmlFor="description" hint="What does your business do, in a few sentences?">
          <textarea id="description" className="input min-h-[100px]" maxLength={1500} value={v.description} onChange={set("description")} />
        </Field>
        <Field label="Products or services" htmlFor="productsServices">
          <textarea id="productsServices" className="input min-h-[100px]" maxLength={1500} value={v.productsServices} onChange={set("productsServices")} />
        </Field>
        <Field label="Target customers" htmlFor="targetCustomers">
          <textarea id="targetCustomers" className="input min-h-[80px]" maxLength={1000} value={v.targetCustomers} onChange={set("targetCustomers")} />
        </Field>
      </section>

      <section className="card space-y-5 p-5 sm:p-6">
        <h2 className="font-semibold">Voice and style</h2>
        <div className="grid gap-5 sm:grid-cols-2">
          <Field label="Brand tone" htmlFor="brandTone">
            <select id="brandTone" className="input" value={v.brandTone} onChange={set("brandTone")}>
              <option value="">No preference</option>
              {withCurrent(BRAND_TONES, v.brandTone).map((i) => <option key={i}>{i}</option>)}
            </select>
          </Field>
          <Field label="Preferred writing style" htmlFor="writingStyle" hint="For example: short sentences, no jargon.">
            <input id="writingStyle" className="input" maxLength={300} value={v.writingStyle} onChange={set("writingStyle")} />
          </Field>
        </div>
        <Field label="Additional business context" htmlFor="additionalContext" hint="Policies, delivery areas, opening hours, anything the AI should know.">
          <textarea id="additionalContext" className="input min-h-[100px]" maxLength={2000} value={v.additionalContext} onChange={set("additionalContext")} />
        </Field>
      </section>

      <div className="flex justify-end">
        <button type="submit" className="btn btn-primary" disabled={busy}>{busy && <Spinner />} Save profile</button>
      </div>
    </form>
  );
}
