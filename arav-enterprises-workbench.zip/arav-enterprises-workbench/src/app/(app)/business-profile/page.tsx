import type { Metadata } from "next";
import { prisma } from "@/lib/db";
import { requireUser } from "@/lib/session";
import { ProfileForm } from "./profile-form";

export const metadata: Metadata = { title: "Business Profile" };
export const dynamic = "force-dynamic";

export default async function BusinessProfilePage() {
  const user = await requireUser();
  const p = await prisma.businessProfile.findUnique({ where: { userId: user.id } }); // own profile only
  return (
    <div className="space-y-8">
      <div>
        <h1 className="page-title">Business Profile</h1>
        <p className="mt-1.5 max-w-2xl text-muted">
          Workbench uses this profile as context for every generation, so the drafts sound like your business.
        </p>
      </div>
      <ProfileForm
        initial={{
          businessName: p?.businessName ?? "",
          industry: p?.industry ?? "",
          businessType: p?.businessType ?? "",
          description: p?.description ?? "",
          productsServices: p?.productsServices ?? "",
          targetCustomers: p?.targetCustomers ?? "",
          brandTone: p?.brandTone ?? "",
          writingStyle: p?.writingStyle ?? "",
          website: p?.website ?? "",
          additionalContext: p?.additionalContext ?? "",
        }}
      />
    </div>
  );
}
