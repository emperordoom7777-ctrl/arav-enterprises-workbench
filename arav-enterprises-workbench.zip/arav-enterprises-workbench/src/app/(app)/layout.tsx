import { redirect } from "next/navigation";
import { requireUser } from "@/lib/session";
import { AppShell, type NavItem } from "@/components/app-shell";

const items: NavItem[] = [
  { href: "/dashboard", label: "Dashboard", icon: "dashboard" },
  { href: "/workspace", label: "AI Workspace", icon: "workspace" },
  { href: "/history", label: "History", icon: "history" },
  { href: "/saved", label: "Saved Content", icon: "saved" },
  { href: "/business-profile", label: "Business Profile", icon: "profile" },
  { href: "/usage", label: "Usage", icon: "usage" },
  { href: "/reviews", label: "Reviews", icon: "reviews" },
  { href: "/settings", label: "Settings", icon: "settings" },
];

export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const user = await requireUser();
  if (!user.onboardingCompleted) redirect("/onboarding");
  return (
    <AppShell items={items} user={{ name: user.name, email: user.email }} variant="user" showAdminLink={user.role === "ADMIN"}>
      {children}
    </AppShell>
  );
}
