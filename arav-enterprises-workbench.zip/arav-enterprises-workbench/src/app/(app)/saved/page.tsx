import type { Metadata } from "next";
import { Suspense } from "react";
import { GenerationList } from "@/components/generation-list";
import { Skeleton } from "@/components/ui";

export const metadata: Metadata = { title: "Saved Content" };

export default function SavedPage() {
  return (
    <Suspense fallback={<Skeleton className="h-64 w-full" />}>
      <GenerationList savedOnly />
    </Suspense>
  );
}
