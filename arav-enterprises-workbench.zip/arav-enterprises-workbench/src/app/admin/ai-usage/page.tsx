import type { Metadata } from "next";
import { requireAdminPage } from "@/lib/session";
import { getAnalytics, getOverview } from "@/lib/admin-data";
import { StatCard } from "@/components/stat-card";
import { BarChart, HorizontalBars } from "@/components/charts";
import { appConfig } from "@/lib/config";

export const metadata: Metadata = { title: "AI usage" };
export const dynamic = "force-dynamic";

export default async function AdminAiUsagePage() {
  await requireAdminPage();
  const [o, a] = await Promise.all([getOverview(), getAnalytics()]);
  return (
    <div className="space-y-8">
      <div>
        <h1 className="page-title">AI usage</h1>
        <p className="mt-1.5 text-muted">Model: {appConfig.ai.model}. Provider {appConfig.ai.isConfigured ? "is configured." : "is NOT configured. Set OPENAI_API_KEY."}</p>
      </div>
      <div className="grid gap-4 sm:grid-cols-3">
        <StatCard label="Total generations" value={o.totalGenerations} />
        <StatCard label="Today" value={a.generationsToday} />
        <StatCard label="This month" value={a.generationsThisMonth} />
      </div>
      <div className="grid gap-6 lg:grid-cols-2">
        <section className="card p-5"><h2 className="mb-4 font-semibold">Daily generations (30 days)</h2><BarChart data={a.dailyGenerations} title="Daily generations" /></section>
        <section className="card p-5"><h2 className="mb-4 font-semibold">Monthly generations</h2><BarChart data={a.monthlyGenerations} title="Monthly generations" /></section>
        <section className="card p-5"><h2 className="mb-4 font-semibold">Most popular tasks</h2><HorizontalBars data={a.popularTasks} /></section>
        <section className="card p-5">
          <h2 className="mb-4 font-semibold">Most active users</h2>
          {a.mostActiveUsers.length === 0 ? <p className="py-6 text-sm text-muted">No data yet.</p> : (
            <ol className="divide-y divide-line">
              {a.mostActiveUsers.map((u) => (
                <li key={u.id} className="flex items-center justify-between gap-3 py-2.5 text-sm">
                  <div className="min-w-0"><p className="truncate font-medium">{u.name}</p><p className="truncate text-xs text-muted">{u.email}</p></div>
                  <span className="tabular-nums text-muted">{u.generations}</span>
                </li>
              ))}
            </ol>
          )}
        </section>
      </div>
    </div>
  );
}
