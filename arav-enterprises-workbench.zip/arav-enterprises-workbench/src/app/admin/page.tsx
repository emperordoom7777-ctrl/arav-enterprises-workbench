import type { Metadata } from "next";
import { requireAdminPage } from "@/lib/session";
import { getAnalytics, getOverview } from "@/lib/admin-data";
import { StatCard } from "@/components/stat-card";
import { BarChart, HorizontalBars, LineChart } from "@/components/charts";

export const metadata: Metadata = { title: "Admin overview" };
export const dynamic = "force-dynamic";

export default async function AdminOverviewPage() {
  await requireAdminPage();
  const [o, a] = await Promise.all([getOverview(), getAnalytics()]);

  return (
    <div className="space-y-8">
      <div>
        <h1 className="page-title">Overview</h1>
        <p className="mt-1.5 text-muted">How Arav Enterprises Workbench is doing.</p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Total users" value={o.totalUsers} />
        <StatCard label="Active users" value={o.activeUsers} hint="Generated content in the last 30 days" />
        <StatCard label="New users this month" value={o.newUsersThisMonth} />
        <StatCard label="Total AI generations" value={o.totalGenerations} />
        <StatCard label="Total saved content" value={o.totalSaved} />
        <StatCard label="Total reviews" value={o.totalReviews} />
        <StatCard label="Approved reviews" value={o.approvedReviews} />
        <StatCard label="Pending reviews" value={o.pendingReviews} />
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <section className="card p-5"><h2 className="mb-4 font-semibold">User growth (12 months)</h2><LineChart data={a.userGrowth} title="User growth" /></section>
        <section className="card p-5"><h2 className="mb-4 font-semibold">AI generations (last 30 days)</h2><BarChart data={a.dailyGenerations} title="AI generations per day" /></section>
        <section className="card p-5"><h2 className="mb-4 font-semibold">New users per month</h2><BarChart data={a.newUsersPerMonth} title="New users per month" /></section>
        <section className="card p-5"><h2 className="mb-4 font-semibold">Most popular AI tasks</h2><HorizontalBars data={a.popularTasks.slice(0, 6)} /></section>
      </div>
    </div>
  );
}
