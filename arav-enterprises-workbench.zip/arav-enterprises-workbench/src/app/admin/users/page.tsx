import type { Metadata } from "next";
import { requireAdminPage } from "@/lib/session";
import { UsersTable } from "./users-table";

export const metadata: Metadata = { title: "Users" };

export default async function AdminUsersPage() {
  await requireAdminPage();
  return (
    <div className="space-y-6">
      <div>
        <h1 className="page-title">Users</h1>
        <p className="mt-1.5 text-muted">Account details and usage statistics. Generated content is never shown here.</p>
      </div>
      <UsersTable />
    </div>
  );
}
