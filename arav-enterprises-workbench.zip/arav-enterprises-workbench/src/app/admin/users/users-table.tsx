"use client";

import { useCallback, useEffect, useState } from "react";
import { Search, Users } from "lucide-react";
import { api, errorMessage } from "@/lib/client";
import { EmptyState, ErrorNotice, Modal, Skeleton, Spinner } from "@/components/ui";
import { formatDate } from "@/lib/utils";

interface U {
  id: string; name: string; email: string; role: "USER" | "ADMIN"; createdAt: string; onboardingCompleted: boolean;
  businessName: string | null; industry: string | null; storedGenerations: number; totalGenerations: number;
  monthGenerations: number; lastActive: string | null;
}
interface Res { users: U[]; total: number; page: number; pageSize: number }

export function UsersTable() {
  const [q, setQ] = useState("");
  const [dq, setDq] = useState("");
  const [page, setPage] = useState(1);
  const [data, setData] = useState<Res | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [selected, setSelected] = useState<U | null>(null);

  useEffect(() => {
    const t = setTimeout(() => { setDq(q); setPage(1); }, 300);
    return () => clearTimeout(t);
  }, [q]);

  const load = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const qs = new URLSearchParams({ page: String(page) });
      if (dq) qs.set("q", dq);
      setData(await api<Res>(`/api/admin/users?${qs.toString()}`));
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setLoading(false);
    }
  }, [page, dq]);

  useEffect(() => { load(); }, [load]);

  const pages = data ? Math.max(1, Math.ceil(data.total / data.pageSize)) : 1;

  return (
    <div className="space-y-4">
      <div className="relative max-w-md">
        <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted" aria-hidden />
        <input className="input pl-10" placeholder="Search by name or email" aria-label="Search users" value={q} onChange={(e) => setQ(e.target.value)} />
      </div>
      {error && <ErrorNotice message={error} onRetry={load} />}

      <div className="card overflow-hidden">
        {loading && !data ? (
          <div className="space-y-3 p-5">{[0, 1, 2, 3].map((i) => <Skeleton key={i} className="h-12 w-full" />)}</div>
        ) : data && data.users.length === 0 ? (
          <EmptyState icon={Users} title="No users found" description="Try a different search." />
        ) : data ? (
          <>
            {/* Desktop table */}
            <div className="hidden md:block">
              <table className="w-full text-sm">
                <thead className="border-b border-line bg-sunken/50 text-left text-xs text-muted">
                  <tr><th className="px-5 py-3 font-medium">User</th><th className="px-3 py-3 font-medium">Joined</th><th className="px-3 py-3 font-medium text-right">This month</th><th className="px-3 py-3 font-medium text-right">Total</th><th className="px-5 py-3" /></tr>
                </thead>
                <tbody className="divide-y divide-line">
                  {data.users.map((u) => (
                    <tr key={u.id} className="hover:bg-sunken/40">
                      <td className="px-5 py-3"><p className="font-medium">{u.name} {u.role === "ADMIN" && <span className="badge badge-accent ml-1">Admin</span>}</p><p className="text-xs text-muted">{u.email}</p></td>
                      <td className="px-3 py-3 text-muted">{formatDate(u.createdAt)}</td>
                      <td className="px-3 py-3 text-right tabular-nums">{u.monthGenerations}</td>
                      <td className="px-3 py-3 text-right tabular-nums">{u.totalGenerations}</td>
                      <td className="px-5 py-3 text-right"><button type="button" className="btn btn-ghost btn-sm" onClick={() => setSelected(u)}>Details</button></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {/* Mobile cards */}
            <ul className="divide-y divide-line md:hidden">
              {data.users.map((u) => (
                <li key={u.id}>
                  <button type="button" onClick={() => setSelected(u)} className="block w-full px-4 py-4 text-left">
                    <p className="font-medium">{u.name} {u.role === "ADMIN" && <span className="badge badge-accent ml-1">Admin</span>}</p>
                    <p className="truncate text-xs text-muted">{u.email}</p>
                    <p className="mt-1 text-xs text-muted">Joined {formatDate(u.createdAt)} · {u.totalGenerations} generations</p>
                  </button>
                </li>
              ))}
            </ul>
          </>
        ) : null}
      </div>

      {data && data.total > data.pageSize && (
        <div className="flex items-center justify-between text-sm">
          <span className="text-muted">Page {page} of {pages} · {data.total} users</span>
          <div className="flex gap-2">
            <button type="button" className="btn btn-secondary btn-sm" disabled={page <= 1 || loading} onClick={() => setPage((p) => p - 1)}>Previous</button>
            <button type="button" className="btn btn-secondary btn-sm" disabled={page >= pages || loading} onClick={() => setPage((p) => p + 1)}>{loading && <Spinner className="h-3 w-3" />} Next</button>
          </div>
        </div>
      )}

      <Modal open={Boolean(selected)} onClose={() => setSelected(null)} title={selected?.name ?? ""}>
        {selected && (
          <dl className="grid grid-cols-[auto_1fr] gap-x-6 gap-y-3 text-sm">
            <dt className="text-muted">Email</dt><dd className="break-all">{selected.email}</dd>
            <dt className="text-muted">Role</dt><dd>{selected.role}</dd>
            <dt className="text-muted">Joined</dt><dd>{formatDate(selected.createdAt, true)}</dd>
            <dt className="text-muted">Last active</dt><dd>{selected.lastActive ? formatDate(selected.lastActive) : "No generations yet"}</dd>
            <dt className="text-muted">Business</dt><dd>{selected.businessName ?? "Not provided"}{selected.industry ? ` (${selected.industry})` : ""}</dd>
            <dt className="text-muted">Generations this month</dt><dd>{selected.monthGenerations}</dd>
            <dt className="text-muted">Total generations</dt><dd>{selected.totalGenerations}</dd>
            <dt className="text-muted">Currently stored</dt><dd>{selected.storedGenerations}</dd>
          </dl>
        )}
      </Modal>
    </div>
  );
}
