import type { Metadata } from "next";
import { Activity as ActivityIcon } from "lucide-react";
import { requireAdminPage } from "@/lib/session";
import { listActivity } from "@/lib/admin-data";
import { EmptyState } from "@/components/ui";
import { TASK_BY_ID } from "@/lib/tasks";
import { formatDate } from "@/lib/utils";

export const metadata: Metadata = { title: "Activity" };
export const dynamic = "force-dynamic";

const labels: Record<string, string> = {
  USER_REGISTERED: "New user registration",
  PROFILE_CREATED: "Business profile created",
  GENERATION_CREATED: "AI generation",
  REVIEW_SUBMITTED: "Review submitted",
  REVIEW_MODERATED: "Review moderated",
  ACCOUNT_DELETED: "Account deleted",
};

export default async function AdminActivityPage() {
  await requireAdminPage();
  const rows = await listActivity(100);
  return (
    <div className="space-y-6">
      <div>
        <h1 className="page-title">Activity</h1>
        <p className="mt-1.5 text-muted">The latest 100 events. Prompts and generated content are never logged.</p>
      </div>
      <div className="card overflow-hidden">
        {rows.length === 0 ? (
          <EmptyState icon={ActivityIcon} title="No activity yet" />
        ) : (
          <ul className="divide-y divide-line">
            {rows.map((r) => (
              <li key={r.id} className="flex flex-wrap items-center justify-between gap-2 px-5 py-3 text-sm">
                <span>
                  <span className="font-medium">{labels[r.type] ?? r.type}</span>
                  {r.type === "GENERATION_CREATED" && r.note && TASK_BY_ID[r.note as keyof typeof TASK_BY_ID] ? ` · ${TASK_BY_ID[r.note as keyof typeof TASK_BY_ID].label}` : ""}
                  {r.type === "REVIEW_MODERATED" && r.note ? ` · ${r.note}` : ""}
                  {r.userName ? <span className="text-muted"> · {r.userName}</span> : null}
                </span>
                <span className="text-xs text-muted">{formatDate(r.createdAt, true)}</span>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
