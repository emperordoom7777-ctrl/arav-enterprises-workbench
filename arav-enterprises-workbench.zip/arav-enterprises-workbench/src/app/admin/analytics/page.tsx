import type { Metadata } from "next";
import { requireAdminPage } from "@/lib/session";
import { getAnalytics } from "@/lib/admin-data";
import { BarChart, LineChart } from "@/components/charts";

export const metadata: Metadata = { title: "Analytics" };
export const dynamic = "force-dynamic";

export default async function AdminAnalyticsPage() {
  await requireAdminPage();
  const a = await getAnalytics();
  return (
    <div className="space-y-8">
      <div>
        <h1 className="page-title">Analytics</h1>
        <p className="mt-1.5 text-muted">Growth and activity over time.</p>
      </div>
      <div className="grid gap-6 lg:grid-cols-2">
        <section className="card p-5"><h2 className="mb-4 font-semibold">User growth (cumulative)</h2><LineChart data={a.userGrowth} title="User growth" /></section>
        <section className="card p-5"><h2 className="mb-4 font-semibold">New users per month</h2><BarChart data={a.newUsersPerMonth} title="New users per month" /></section>
        <section className="card p-5"><h2 className="mb-4 font-semibold">Generations per month</h2><BarChart data={a.monthlyGenerations} title="Generations per month" /></section>
        <section className="card p-5"><h2 className="mb-4 font-semibold">Generations per day (30 days)</h2><LineChart data={a.dailyGenerations} title="Generations per day" /></section>
      </div>
    </div>
  );
}
