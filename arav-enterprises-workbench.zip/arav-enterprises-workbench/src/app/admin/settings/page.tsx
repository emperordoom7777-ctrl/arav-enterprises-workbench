import type { Metadata } from "next";
import { requireAdminPage } from "@/lib/session";
import { appConfig } from "@/lib/config";

export const metadata: Metadata = { title: "Admin settings" };
export const dynamic = "force-dynamic";

export default async function AdminSettingsPage() {
  await requireAdminPage();
  const rows: [string, string][] = [
    ["Product", `${appConfig.name} v${appConfig.version} (Free edition)`],
    ["AI provider", appConfig.ai.isConfigured ? "Configured" : "Not configured"],
    ["AI model", appConfig.ai.model],
    ["Free monthly generation limit", String(appConfig.limits.monthly)],
    ["Free daily generation limit", String(appConfig.limits.daily)],
  ];
  return (
    <div className="space-y-6">
      <div>
        <h1 className="page-title">Settings</h1>
        <p className="mt-1.5 max-w-2xl text-muted">
          These values come from environment variables. To change them, update FREE_MONTHLY_GENERATION_LIMIT, FREE_DAILY_GENERATION_LIMIT or OPENAI_MODEL and restart the app.
        </p>
      </div>
      <dl className="card max-w-2xl divide-y divide-line">
        {rows.map(([k, v]) => (
          <div key={k} className="flex flex-wrap justify-between gap-2 px-5 py-3.5 text-sm">
            <dt className="text-muted">{k}</dt>
            <dd className="font-medium">{v}</dd>
          </div>
        ))}
      </dl>
    </div>
  );
}
