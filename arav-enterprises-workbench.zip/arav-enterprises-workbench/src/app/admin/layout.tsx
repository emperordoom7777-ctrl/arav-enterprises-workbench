import { requireAdminPage } from "@/lib/session";
import { AppShell, type NavItem } from "@/components/app-shell";

const items: NavItem[] = [
  { href: "/admin", label: "Overview", icon: "dashboard", exact: true },
  { href: "/admin/users", label: "Users", icon: "users" },
  { href: "/admin/analytics", label: "Analytics", icon: "analytics" },
  { href: "/admin/ai-usage", label: "AI Usage", icon: "ai" },
  { href: "/admin/reviews", label: "Reviews", icon: "reviews" },
  { href: "/admin/activity", label: "Activity", icon: "activity" },
  { href: "/admin/settings", label: "Settings", icon: "settings" },
];

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const admin = await requireAdminPage(); // server-side role === ADMIN check against the database
  return (
    <AppShell items={items} user={{ name: admin.name, email: admin.email }} variant="admin">
      {children}
    </AppShell>
  );
}
