import type { Metadata } from "next";
import { requireAdminPage } from "@/lib/session";
import { listReviews } from "@/lib/admin-data";
import { ReviewsManager } from "./reviews-manager";

export const metadata: Metadata = { title: "Review moderation" };
export const dynamic = "force-dynamic";

export default async function AdminReviewsPage() {
  await requireAdminPage();
  const reviews = await listReviews("all");
  return (
    <div className="space-y-6">
      <div>
        <h1 className="page-title">Reviews</h1>
        <p className="mt-1.5 text-muted">Only approved reviews appear on the public landing page.</p>
      </div>
      <ReviewsManager initial={JSON.parse(JSON.stringify(reviews))} />
    </div>
  );
}
