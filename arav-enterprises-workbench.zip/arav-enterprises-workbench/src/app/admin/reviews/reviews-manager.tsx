"use client";

import { useState } from "react";
import { Check, Star, Trash2, X } from "lucide-react";
import { api, errorMessage } from "@/lib/client";
import { ConfirmDialog, EmptyState, Stars } from "@/components/ui";
import { useToast } from "@/components/toast";
import { cn, formatDate } from "@/lib/utils";

type Status = "PENDING" | "APPROVED" | "REJECTED";
interface R { id: string; rating: number; title: string; message: string; businessName: string | null; status: Status; createdAt: string; userName: string; userEmail: string }

const tabs = [
  { id: "pending", label: "Pending" },
  { id: "approved", label: "Approved" },
  { id: "all", label: "All reviews" },
] as const;

const badge: Record<Status, string> = { PENDING: "badge-warn", APPROVED: "badge-success", REJECTED: "badge-danger" };

export function ReviewsManager({ initial }: { initial: R[] }) {
  const { toast } = useToast();
  const [reviews, setReviews] = useState<R[]>(initial);
  const [tab, setTab] = useState<(typeof tabs)[number]["id"]>("pending");
  const [busyId, setBusyId] = useState<string | null>(null);
  const [deleting, setDeleting] = useState<R | null>(null);

  const visible = reviews.filter((r) => (tab === "all" ? true : tab === "pending" ? r.status === "PENDING" : r.status === "APPROVED"));
  const count = (id: (typeof tabs)[number]["id"]) => reviews.filter((r) => (id === "all" ? true : id === "pending" ? r.status === "PENDING" : r.status === "APPROVED")).length;

  async function moderate(r: R, action: "approve" | "reject") {
    setBusyId(r.id);
    try {
      await api(`/api/admin/reviews/${r.id}`, { method: "PATCH", json: { action } });
      setReviews((cur) => cur.map((x) => (x.id === r.id ? { ...x, status: action === "approve" ? "APPROVED" : "REJECTED" } : x)));
      toast(action === "approve" ? "Review approved" : "Review rejected");
    } catch (err) {
      toast(errorMessage(err), "error");
    } finally {
      setBusyId(null);
    }
  }

  async function remove() {
    if (!deleting) return;
    setBusyId(deleting.id);
    try {
      await api(`/api/admin/reviews/${deleting.id}`, { method: "DELETE" });
      setReviews((cur) => cur.filter((x) => x.id !== deleting.id));
      setDeleting(null);
      toast("Review deleted");
    } catch (err) {
      toast(errorMessage(err), "error");
    } finally {
      setBusyId(null);
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex gap-1 rounded-xl bg-sunken p-1" role="tablist">
        {tabs.map((t) => (
          <button
            key={t.id}
            type="button"
            role="tab"
            aria-selected={tab === t.id}
            onClick={() => setTab(t.id)}
            className={cn("flex-1 rounded-lg px-3 py-2 text-sm font-medium transition-colors", tab === t.id ? "bg-surface shadow-card" : "text-muted hover:text-ink")}
          >
            {t.label} <span className="text-xs text-muted">({count(t.id)})</span>
          </button>
        ))}
      </div>

      {visible.length === 0 ? (
        <div className="card"><EmptyState icon={Star} title="No reviews here" description={tab === "pending" ? "Nothing is waiting for moderation." : "Reviews will appear here."} /></div>
      ) : (
        <ul className="space-y-3">
          {visible.map((r) => (
            <li key={r.id} className="card p-5">
              <div className="flex flex-wrap items-center gap-2">
                <Stars value={r.rating} size="sm" />
                <span className={`badge ${badge[r.status]}`}>{r.status.charAt(0) + r.status.slice(1).toLowerCase()}</span>
                <span className="ml-auto text-xs text-muted">{formatDate(r.createdAt)}</span>
              </div>
              <h3 className="mt-2 font-semibold">{r.title}</h3>
              <p className="mt-1 whitespace-pre-wrap break-words text-sm text-muted">{r.message}</p>
              <p className="mt-3 text-xs text-muted">{r.userName} ({r.userEmail}){r.businessName ? ` · ${r.businessName}` : ""}</p>
              <div className="mt-4 flex flex-wrap gap-2">
                {r.status !== "APPROVED" && <button type="button" className="btn btn-primary btn-sm" disabled={busyId === r.id} onClick={() => moderate(r, "approve")}><Check className="h-3.5 w-3.5" /> Approve</button>}
                {r.status !== "REJECTED" && <button type="button" className="btn btn-secondary btn-sm" disabled={busyId === r.id} onClick={() => moderate(r, "reject")}><X className="h-3.5 w-3.5" /> Reject</button>}
                <button type="button" className="btn btn-secondary btn-sm text-danger" disabled={busyId === r.id} onClick={() => setDeleting(r)}><Trash2 className="h-3.5 w-3.5" /> Delete</button>
              </div>
            </li>
          ))}
        </ul>
      )}

      <ConfirmDialog open={Boolean(deleting)} title="Delete this review?" message="The review is removed permanently. The author will be able to submit a new one." busy={busyId !== null} onConfirm={remove} onCancel={() => setDeleting(null)} />
    </div>
  );
}
