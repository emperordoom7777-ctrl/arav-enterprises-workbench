export default function Loading() {
  return (
    <div className="mx-auto max-w-6xl space-y-4 px-4 py-10" aria-busy="true">
      <div className="skeleton h-8 w-64" />
      <div className="skeleton h-40 w-full" />
      <div className="skeleton h-40 w-full" />
    </div>
  );
}
