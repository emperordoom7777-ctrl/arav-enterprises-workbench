import type { TaskType } from "@prisma/client";

export interface TaskDefinition {
  id: TaskType;
  label: string;
  description: string;
  placeholder: string;
  /** Task-specific writing guidance given to the AI model. */
  guidance: string;
}

export const TASKS: TaskDefinition[] = [
  {
    id: "CUSTOMER_REPLY",
    label: "Customer Reply",
    description: "Answer a customer message clearly and kindly.",
    placeholder: "Paste the customer's message and tell me how you want to respond.",
    guidance:
      "Write a reply to a customer. Be courteous, address every question they asked, and end with a clear next step.",
  },
  {
    id: "MARKETING_POST",
    label: "Marketing Post",
    description: "A promotional post for your offer or campaign.",
    placeholder: "What are you promoting, and who should see it?",
    guidance:
      "Write a marketing post with a strong opening line, the main benefit, and a clear call to action. Avoid exaggerated claims.",
  },
  {
    id: "SOCIAL_CAPTION",
    label: "Social Media Caption",
    description: "Short captions for Instagram, Facebook, LinkedIn and more.",
    placeholder: "Describe the photo, product or announcement, and the platform.",
    guidance:
      "Write 3 caption options of different lengths. Add a few relevant hashtags to each. Keep each suited to social media.",
  },
  {
    id: "EMAIL_DRAFT",
    label: "Email Draft",
    description: "A complete email with subject line.",
    placeholder: "Who is the email for, and what should it achieve?",
    guidance:
      "Write a complete email. Start with 'Subject:' on the first line, then a greeting, a concise body, and a professional sign-off.",
  },
  {
    id: "PRODUCT_DESCRIPTION",
    label: "Product Description",
    description: "Clear, persuasive descriptions for products or services.",
    placeholder: "Name the product and list its key features and who it is for.",
    guidance:
      "Write a product description that leads with the benefit, covers key features, and ends with a short call to action. Use only facts provided; do not invent specifications.",
  },
  {
    id: "BUSINESS_ANNOUNCEMENT",
    label: "Business Announcement",
    description: "News, updates, launches and notices.",
    placeholder: "What is the news, and when does it take effect?",
    guidance:
      "Write a clear business announcement: what is happening, when, why it matters to the audience, and what they should do.",
  },
  {
    id: "FOLLOW_UP",
    label: "Follow-up Message",
    description: "Polite nudges after a meeting, quote or inquiry.",
    placeholder: "What happened before, and what response are you waiting for?",
    guidance:
      "Write a short, polite follow-up that references the earlier interaction, restates the ask, and makes replying easy.",
  },
  {
    id: "SALES_MESSAGE",
    label: "Sales Message",
    description: "Outreach that turns interest into conversations.",
    placeholder: "Who are you contacting, and what are you offering?",
    guidance:
      "Write a sales message that is personal, benefit-led and concise, with one clear call to action. Do not be pushy or make unverifiable claims.",
  },
  {
    id: "QUOTATION",
    label: "Quotation",
    description: "A structured price quote for a client.",
    placeholder: "List the items or services, quantities, prices and terms.",
    guidance:
      "Write a professional quotation with a header, an itemised list using ONLY the items and prices provided, a total if it can be computed from them, validity and terms. Never invent prices; mark missing details as [to be confirmed].",
  },
  {
    id: "PROPOSAL",
    label: "Proposal",
    description: "A business proposal with scope and next steps.",
    placeholder: "Who is it for, what problem are you solving, and what do you propose?",
    guidance:
      "Write a business proposal with: overview, understanding of the client's need, proposed solution, scope, timeline, and next steps. Mark missing details as [to be confirmed] instead of inventing them.",
  },
  {
    id: "BUSINESS_SUMMARY",
    label: "Business Summary",
    description: "Condense reports, updates or notes.",
    placeholder: "Paste the text you want summarised.",
    guidance:
      "Summarise the provided material into a short overview followed by the key points and any recommended actions. Do not add information that is not in the source.",
  },
  {
    id: "MEETING_SUMMARY",
    label: "Meeting Summary",
    description: "Notes into decisions and action items.",
    placeholder: "Paste your meeting notes or transcript.",
    guidance:
      "Turn the notes into a meeting summary with: key discussion points, decisions made, and action items (owner and deadline where stated). Do not invent owners or dates.",
  },
  {
    id: "SUPPORT_RESPONSE",
    label: "Customer Support Response",
    description: "Helpful answers to support requests and complaints.",
    placeholder: "Describe the customer's issue and what you can offer.",
    guidance:
      "Write a customer support response that acknowledges the issue, explains the resolution or next steps, and keeps a calm, helpful tone. Do not promise refunds, timelines or policies that were not provided.",
  },
];

export const TASK_BY_ID: Record<TaskType, TaskDefinition> = Object.fromEntries(
  TASKS.map((t) => [t.id, t]),
) as Record<TaskType, TaskDefinition>;

export const TASK_IDS = TASKS.map((t) => t.id) as [TaskType, ...TaskType[]];

export const BRAND_TONES = [
  "Professional",
  "Friendly",
  "Casual",
  "Formal",
  "Persuasive",
  "Warm and empathetic",
  "Confident and bold",
  "Luxury and refined",
];

export const INDUSTRIES = [
  "Retail & E-commerce",
  "Food & Hospitality",
  "Professional Services",
  "Technology & Software",
  "Education & Training",
  "Health & Wellness",
  "Real Estate",
  "Manufacturing",
  "Creative & Media",
  "Freelance / Consulting",
  "Other",
];

export const BUSINESS_TYPES = [
  "Freelancer",
  "Small business",
  "Startup",
  "Agency",
  "Online store",
  "Local shop or service",
  "Other",
];

export const AI_GOALS = [
  "Customer communication",
  "Marketing",
  "Social media",
  "Emails",
  "Product descriptions",
  "General business assistance",
];
