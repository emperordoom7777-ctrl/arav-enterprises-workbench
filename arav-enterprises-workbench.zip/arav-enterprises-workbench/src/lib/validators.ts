import { z } from "zod";
import { TASK_IDS } from "@/lib/tasks";

const optionalText = (max: number) =>
  z
    .string()
    .trim()
    .max(max, `Must be ${max} characters or fewer`)
    .optional()
    .nullable()
    .transform((v) => (v && v.length ? v : null));

const optionalUrl = z
  .string()
  .trim()
  .max(200, "Must be 200 characters or fewer")
  .optional()
  .nullable()
  .refine(
    (v) => {
      if (!v) return true;
      try {
        const u = new URL(/^https?:\/\//i.test(v) ? v : `https://${v}`);
        return u.hostname.includes(".");
      } catch {
        return false;
      }
    },
    { message: "Enter a valid website address" },
  )
  .transform((v) => (v ? (/^https?:\/\//i.test(v) ? v : `https://${v}`) : null));

export const registerSchema = z.object({
  name: z.string().trim().min(2, "Enter your full name").max(80, "Name is too long"),
  email: z.string().trim().toLowerCase().email("Enter a valid email address").max(254),
  password: z
    .string()
    .min(8, "Password must be at least 8 characters")
    .max(72, "Password must be 72 characters or fewer")
    .regex(/[A-Za-z]/, "Password must include a letter")
    .regex(/[0-9]/, "Password must include a number"),
});

export const loginSchema = z.object({
  email: z.string().trim().toLowerCase().email().max(254),
  password: z.string().min(1).max(72),
});

export const businessProfileSchema = z.object({
  businessName: optionalText(120),
  industry: optionalText(80),
  businessType: optionalText(80),
  description: optionalText(1500),
  productsServices: optionalText(1500),
  targetCustomers: optionalText(1000),
  brandTone: optionalText(60),
  writingStyle: optionalText(300),
  website: optionalUrl,
  additionalContext: optionalText(2000),
});

export const onboardingSchema = z.object({
  businessName: optionalText(120),
  industry: optionalText(80),
  businessType: optionalText(80),
  goals: z.array(z.string().trim().max(60)).max(10).optional().default([]),
});

export const generateSchema = z.object({
  taskType: z.enum(TASK_IDS),
  instructions: z.string().trim().min(3, "Tell the assistant what you need").max(4000, "Instructions are too long (4,000 characters max)"),
  context: optionalText(4000),
  refine: z
    .object({
      action: z.enum(["improve", "shorten", "expand"]),
      previousOutput: z.string().trim().min(1).max(12000),
    })
    .optional(),
});

export const generationQuerySchema = z.object({
  q: z.string().trim().max(100).optional(),
  task: z.enum(TASK_IDS).optional(),
  saved: z.enum(["1", "0"]).optional(),
  page: z.coerce.number().int().min(1).max(1000).default(1),
});

export const saveSchema = z.object({ isSaved: z.boolean() });

export const reviewSchema = z.object({
  rating: z.coerce.number().int().min(1, "Choose a star rating").max(5),
  title: z.string().trim().min(3, "Add a short title").max(100, "Title is too long"),
  message: z.string().trim().min(10, "Tell us a little more (10 characters minimum)").max(1500, "Review is too long (1,500 characters max)"),
  businessName: optionalText(120),
});

export const accountUpdateSchema = z.object({
  name: z.string().trim().min(2, "Enter your full name").max(80),
});

export const accountDeleteSchema = z.object({
  confirm: z.literal("DELETE", { errorMap: () => ({ message: 'Type "DELETE" to confirm' }) }),
});

export const adminReviewActionSchema = z.object({ action: z.enum(["approve", "reject"]) });

export const adminReviewQuerySchema = z.object({
  status: z.enum(["pending", "approved", "all"]).default("pending"),
});

export const adminUsersQuerySchema = z.object({
  q: z.string().trim().max(100).optional(),
  page: z.coerce.number().int().min(1).max(1000).default(1),
});
