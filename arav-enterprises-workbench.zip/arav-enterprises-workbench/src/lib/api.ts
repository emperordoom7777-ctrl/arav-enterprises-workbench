import { NextResponse, type NextRequest } from "next/server";
import { Prisma } from "@prisma/client";
import { ZodError } from "zod";

export class ApiError extends Error {
  constructor(
    public readonly status: number,
    message: string,
    public readonly code?: string,
  ) {
    super(message);
    this.name = "ApiError";
  }
}

export function errorResponse(err: unknown): NextResponse {
  if (err instanceof ApiError) {
    return NextResponse.json({ error: err.message, code: err.code }, { status: err.status });
  }
  if (err instanceof ZodError) {
    const first = err.issues[0];
    return NextResponse.json(
      { error: first?.message ?? "Some fields are invalid.", code: "INVALID_INPUT" },
      { status: 400 },
    );
  }
  if (err instanceof SyntaxError) {
    return NextResponse.json({ error: "The request could not be read.", code: "INVALID_INPUT" }, { status: 400 });
  }
  if (err instanceof Prisma.PrismaClientKnownRequestError && err.code === "P2002") {
    return NextResponse.json({ error: "That already exists.", code: "CONFLICT" }, { status: 409 });
  }
  // Log technical details on the server only; show a friendly message to the user.
  console.error("[api] unexpected error:", err);
  return NextResponse.json(
    { error: "Something went wrong on our side. Please try again in a moment.", code: "SERVER_ERROR" },
    { status: 500 },
  );
}

type Handler<C> = (req: NextRequest, ctx: C) => Promise<NextResponse>;

/** Wraps a route handler with consistent, safe error handling. */
export function route<C = unknown>(fn: Handler<C>): Handler<C> {
  return async (req, ctx) => {
    try {
      return await fn(req, ctx);
    } catch (err) {
      return errorResponse(err);
    }
  };
}
