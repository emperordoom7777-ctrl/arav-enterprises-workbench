import { prisma } from "@/lib/db";
import { appConfig } from "@/lib/config";

export function utcDay(d = new Date()): Date {
  return new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate()));
}

export function utcMonthStart(d = new Date()): Date {
  return new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), 1));
}

export interface UsageSummary {
  total: number;
  month: number;
  day: number;
  monthlyLimit: number;
  dailyLimit: number;
  remainingMonth: number;
  remainingDay: number;
  /** The number of generations the user can still run right now. */
  remaining: number;
  limitReached: boolean;
}

export async function getUsage(userId: string): Promise<UsageSummary> {
  const [total, month, today] = await Promise.all([
    prisma.usageRecord.aggregate({ where: { userId }, _sum: { count: true } }),
    prisma.usageRecord.aggregate({
      where: { userId, date: { gte: utcMonthStart() } },
      _sum: { count: true },
    }),
    prisma.usageRecord.findUnique({ where: { userId_date: { userId, date: utcDay() } } }),
  ]);

  const monthCount = month._sum.count ?? 0;
  const dayCount = today?.count ?? 0;
  const { monthly, daily } = appConfig.limits;
  const remainingMonth = Math.max(0, monthly - monthCount);
  const remainingDay = Math.max(0, daily - dayCount);
  const remaining = Math.min(remainingMonth, remainingDay);

  return {
    total: total._sum.count ?? 0,
    month: monthCount,
    day: dayCount,
    monthlyLimit: monthly,
    dailyLimit: daily,
    remainingMonth,
    remainingDay,
    remaining,
    limitReached: remaining <= 0,
  };
}
