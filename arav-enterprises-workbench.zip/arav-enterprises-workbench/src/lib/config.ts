function int(value: string | undefined, fallback: number, min = 1): number {
  const n = Number.parseInt(value ?? "", 10);
  return Number.isFinite(n) && n >= min ? n : fallback;
}

/** Central, environment-driven configuration. Nothing here is exposed to the browser. */
export const appConfig = {
  name: "Arav Enterprises Workbench",
  company: "Arav Enterprises",
  version: "1.0",
  limits: {
    monthly: int(process.env.FREE_MONTHLY_GENERATION_LIMIT, 100),
    daily: int(process.env.FREE_DAILY_GENERATION_LIMIT, 20),
  },
  ai: {
    model: process.env.OPENAI_MODEL?.trim() || "gpt-4o-mini",
    baseUrl: (process.env.OPENAI_BASE_URL?.trim() || "https://api.openai.com/v1").replace(/\/$/, ""),
    get isConfigured() {
      return Boolean(process.env.OPENAI_API_KEY?.trim());
    },
  },
};

export const AI_NOT_CONFIGURED_MESSAGE =
  "AI generation is currently not configured. Please contact the administrator.";
export const LIMIT_REACHED_MESSAGE =
  "You have reached your current free usage limit. Please try again later.";
