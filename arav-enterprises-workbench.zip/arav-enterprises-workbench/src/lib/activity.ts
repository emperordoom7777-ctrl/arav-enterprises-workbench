import type { ActivityType } from "@prisma/client";
import { prisma } from "@/lib/db";

/** Records a privacy-conscious event. Never throws: logging must not break user flows. */
export async function logActivity(type: ActivityType, userId?: string | null, note?: string) {
  try {
    await prisma.activity.create({
      data: { type, userId: userId ?? null, note: note ? note.slice(0, 120) : null },
    });
  } catch (err) {
    console.error("[activity] failed to log", type, err instanceof Error ? err.message : err);
  }
}
