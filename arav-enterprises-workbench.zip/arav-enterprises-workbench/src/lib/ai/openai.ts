import { appConfig } from "@/lib/config";
import { AIProviderError, type AIProvider, type ChatMessage } from "./provider";

/** OpenAI (or OpenAI-compatible) chat completions provider. Runs on the server only. */
export class OpenAIProvider implements AIProvider {
  readonly name = "openai";
  readonly model = appConfig.ai.model;

  constructor(private readonly apiKey: string) {}

  async generate(messages: ChatMessage[]): Promise<string> {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 60_000);

    try {
      const res = await fetch(`${appConfig.ai.baseUrl}/chat/completions`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${this.apiKey}`,
        },
        body: JSON.stringify({
          model: this.model,
          messages,
          temperature: 0.7,
          max_tokens: 1800,
        }),
        signal: controller.signal,
        cache: "no-store",
      });

      if (!res.ok) {
        // Log provider detail server-side only; never forward it to the browser.
        const detail = await res.text().catch(() => "");
        console.error(`[ai] provider error ${res.status}: ${detail.slice(0, 300)}`);
        throw new AIProviderError("Provider request failed", res.status);
      }

      const data = (await res.json()) as {
        choices?: { message?: { content?: string | null } }[];
      };
      const text = data.choices?.[0]?.message?.content?.trim();
      if (!text) throw new AIProviderError("Provider returned an empty response");
      return text;
    } catch (err) {
      if (err instanceof AIProviderError) throw err;
      console.error("[ai] request failed:", err instanceof Error ? err.message : err);
      throw new AIProviderError("Provider request failed");
    } finally {
      clearTimeout(timeout);
    }
  }
}
