import { OpenAIProvider } from "./openai";
import type { AIProvider } from "./provider";

/** Returns the configured AI provider, or null when no API key is set. */
export function getAIProvider(): AIProvider | null {
  const key = process.env.OPENAI_API_KEY?.trim();
  if (!key) return null;
  return new OpenAIProvider(key);
}

export { AIProviderError } from "./provider";
export type { AIProvider, ChatMessage } from "./provider";
