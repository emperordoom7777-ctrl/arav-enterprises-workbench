export interface ChatMessage {
  role: "system" | "user" | "assistant";
  content: string;
}

export interface AIProvider {
  readonly name: string;
  readonly model: string;
  generate(messages: ChatMessage[]): Promise<string>;
}

export class AIProviderError extends Error {
  constructor(message: string, public readonly status?: number) {
    super(message);
    this.name = "AIProviderError";
  }
}
