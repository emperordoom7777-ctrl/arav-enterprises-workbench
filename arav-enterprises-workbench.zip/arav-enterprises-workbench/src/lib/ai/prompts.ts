import type { BusinessProfile, TaskType } from "@prisma/client";
import { TASK_BY_ID } from "@/lib/tasks";
import type { ChatMessage } from "./provider";

export type RefineAction = "improve" | "shorten" | "expand";

const REFINE_INSTRUCTIONS: Record<RefineAction, string> = {
  improve:
    "Improve the draft below: sharpen the wording, fix any errors, and make it more effective while keeping its meaning and facts unchanged.",
  shorten:
    "Shorten the draft below to roughly half its length. Keep the essential points and the same tone. Do not add new information.",
  expand:
    "Expand the draft below with more helpful detail and smoother flow, roughly 1.5 to 2 times longer. Do not invent facts that are not already stated or implied.",
};

function line(label: string, value?: string | null): string | null {
  return value && value.trim() ? `- ${label}: ${value.trim()}` : null;
}

function profileContext(profile: BusinessProfile | null): string {
  if (!profile) return "No business profile has been provided. Write in a clear, professional, neutral voice.";
  const lines = [
    line("Business name", profile.businessName),
    line("Industry", profile.industry),
    line("Type of business", profile.businessType),
    line("About the business", profile.description),
    line("Products or services", profile.productsServices),
    line("Target customers", profile.targetCustomers),
    line("Brand tone", profile.brandTone),
    line("Preferred writing style", profile.writingStyle),
    line("Website", profile.website),
    line("Additional context", profile.additionalContext),
  ].filter(Boolean);
  return lines.length ? lines.join("\n") : "No business profile details have been provided.";
}

interface PromptInput {
  taskType: TaskType;
  instructions: string;
  context?: string | null;
  profile: BusinessProfile | null;
  refine?: { action: RefineAction; previousOutput: string };
}

export function buildPrompt(input: PromptInput): ChatMessage[] {
  const task = TASK_BY_ID[input.taskType];

  const system = [
    "You are the writing assistant inside Arav Enterprises Workbench, a workspace for business owners, freelancers and small businesses.",
    "Write ready-to-use content that the user can copy and send or publish with minimal edits.",
    "Follow the business profile below, especially the brand tone and writing style. Use the business's real name, products and audience where relevant.",
    "Rules: never invent facts, prices, dates, policies, names or statistics that the user did not provide - use a [placeholder] instead. Do not add commentary about being an AI. Output only the content itself, without preamble.",
    "",
    "BUSINESS PROFILE",
    profileContext(input.profile),
    "",
    `TASK: ${task.label}`,
    task.guidance,
  ].join("\n");

  const userParts: string[] = [];
  if (input.refine) {
    userParts.push(REFINE_INSTRUCTIONS[input.refine.action]);
    userParts.push(`ORIGINAL REQUEST:\n${input.instructions}`);
    if (input.context) userParts.push(`ADDITIONAL CONTEXT:\n${input.context}`);
    userParts.push(`DRAFT:\n${input.refine.previousOutput}`);
  } else {
    userParts.push(`INSTRUCTIONS:\n${input.instructions}`);
    if (input.context) userParts.push(`ADDITIONAL CONTEXT:\n${input.context}`);
  }

  return [
    { role: "system", content: system },
    { role: "user", content: userParts.join("\n\n") },
  ];
}
