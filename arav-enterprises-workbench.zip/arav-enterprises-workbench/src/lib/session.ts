import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import type { Role } from "@prisma/client";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { ApiError } from "@/lib/api";

export interface CurrentUser {
  id: string;
  name: string;
  email: string;
  role: Role;
  onboardingCompleted: boolean;
}

const userSelect = { id: true, name: true, email: true, role: true, onboardingCompleted: true } as const;

/** Reads the signed-in user from the database (never trusts the token for role). */
export async function getCurrentUser(): Promise<CurrentUser | null> {
  const session = await getServerSession(authOptions);
  const id = session?.user?.id;
  if (!id) return null;
  return prisma.user.findUnique({ where: { id }, select: userSelect });
}

/** For server components / layouts: redirects to /login when not signed in. */
export async function requireUser(): Promise<CurrentUser> {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  return user;
}

/** For server components / layouts: only role === ADMIN (checked against the database). */
export async function requireAdminPage(): Promise<CurrentUser> {
  const user = await requireUser();
  if (user.role !== "ADMIN") redirect("/dashboard");
  return user;
}

/** For API routes: throws 401 when not signed in. */
export async function requireApiUser(): Promise<CurrentUser> {
  const user = await getCurrentUser();
  if (!user) throw new ApiError(401, "Please sign in to continue.", "UNAUTHORIZED");
  return user;
}

/** For API routes: throws 401/403 unless role === ADMIN (checked against the database). */
export async function requireApiAdmin(): Promise<CurrentUser> {
  const user = await requireApiUser();
  if (user.role !== "ADMIN") throw new ApiError(403, "You do not have access to this resource.", "FORBIDDEN");
  return user;
}
