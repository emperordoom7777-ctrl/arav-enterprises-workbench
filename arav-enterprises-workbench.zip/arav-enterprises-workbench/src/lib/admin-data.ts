import { Prisma, type TaskType } from "@prisma/client";
import { prisma } from "@/lib/db";
import { utcDay } from "@/lib/usage";
import { TASK_BY_ID } from "@/lib/tasks";

export interface SeriesPoint {
  label: string;
  value: number;
}

function monthKey(d: Date): string {
  return `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, "0")}`;
}

function lastMonths(n: number): { key: string; label: string; start: Date }[] {
  const now = new Date();
  const out: { key: string; label: string; start: Date }[] = [];
  for (let i = n - 1; i >= 0; i--) {
    const start = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() - i, 1));
    out.push({
      key: monthKey(start),
      label: start.toLocaleDateString("en-US", { month: "short", timeZone: "UTC" }),
      start,
    });
  }
  return out;
}

function lastDays(n: number): { key: string; label: string; date: Date }[] {
  const today = utcDay();
  const out: { key: string; label: string; date: Date }[] = [];
  for (let i = n - 1; i >= 0; i--) {
    const date = new Date(today.getTime() - i * 86_400_000);
    out.push({
      key: date.toISOString().slice(0, 10),
      label: date.toLocaleDateString("en-US", { day: "numeric", month: "short", timeZone: "UTC" }),
      date,
    });
  }
  return out;
}

export async function getOverview() {
  const monthStart = new Date(Date.UTC(new Date().getUTCFullYear(), new Date().getUTCMonth(), 1));
  const since30 = new Date(utcDay().getTime() - 29 * 86_400_000);

  const [
    totalUsers,
    newUsersThisMonth,
    activeGroups,
    totalGenerations,
    totalSaved,
    totalReviews,
    approvedReviews,
    pendingReviews,
  ] = await Promise.all([
    prisma.user.count(),
    prisma.user.count({ where: { createdAt: { gte: monthStart } } }),
    prisma.usageRecord.groupBy({ by: ["userId"], where: { date: { gte: since30 } } }),
    prisma.usageRecord.aggregate({ _sum: { count: true } }),
    prisma.generation.count({ where: { isSaved: true } }),
    prisma.review.count(),
    prisma.review.count({ where: { status: "APPROVED" } }),
    prisma.review.count({ where: { status: "PENDING" } }),
  ]);

  return {
    totalUsers,
    activeUsers: activeGroups.length,
    newUsersThisMonth,
    totalGenerations: totalGenerations._sum.count ?? 0,
    totalSaved,
    totalReviews,
    approvedReviews,
    pendingReviews,
  };
}

export async function getAnalytics() {
  const months = lastMonths(12);
  const days = lastDays(30);
  const firstMonth = months[0]!.start;
  const firstDay = days[0]!.date;

  const [userRows, usersBefore, usageByDay, taskGroups, activeGroups, todayAgg, monthAgg] = await Promise.all([
    prisma.$queryRaw<{ month: Date; count: bigint }[]>(Prisma.sql`
      SELECT date_trunc('month', "createdAt") AS month, COUNT(*)::bigint AS count
      FROM "User"
      WHERE "createdAt" >= ${firstMonth}
      GROUP BY 1
      ORDER BY 1`),
    prisma.user.count({ where: { createdAt: { lt: firstMonth } } }),
    prisma.usageRecord.groupBy({
      by: ["date"],
      where: { date: { gte: firstMonth } },
      _sum: { count: true },
    }),
    prisma.generation.groupBy({ by: ["taskType"], _count: { _all: true } }),
    prisma.usageRecord.groupBy({
      by: ["userId"],
      _sum: { count: true },
      orderBy: { _sum: { count: "desc" } },
      take: 10,
    }),
    prisma.usageRecord.aggregate({ where: { date: utcDay() }, _sum: { count: true } }),
    prisma.usageRecord.aggregate({
      where: { date: { gte: new Date(Date.UTC(new Date().getUTCFullYear(), new Date().getUTCMonth(), 1)) } },
      _sum: { count: true },
    }),
  ]);

  // New users per month + cumulative growth
  const newByMonth = new Map(userRows.map((r) => [monthKey(new Date(r.month)), Number(r.count)]));
  let running = usersBefore;
  const newUsersPerMonth: SeriesPoint[] = [];
  const userGrowth: SeriesPoint[] = [];
  for (const m of months) {
    const added = newByMonth.get(m.key) ?? 0;
    running += added;
    newUsersPerMonth.push({ label: m.label, value: added });
    userGrowth.push({ label: m.label, value: running });
  }

  // Generations per day (last 30) and per month (last 12)
  const dayMap = new Map<string, number>();
  const monthMap = new Map<string, number>();
  for (const row of usageByDay) {
    const d = new Date(row.date);
    const c = row._sum.count ?? 0;
    dayMap.set(d.toISOString().slice(0, 10), c);
    monthMap.set(monthKey(d), (monthMap.get(monthKey(d)) ?? 0) + c);
  }
  const dailyGenerations: SeriesPoint[] = days
    .filter((d) => d.date >= firstDay)
    .map((d) => ({ label: d.label, value: dayMap.get(d.key) ?? 0 }));
  const monthlyGenerations: SeriesPoint[] = months.map((m) => ({ label: m.label, value: monthMap.get(m.key) ?? 0 }));

  const popularTasks = taskGroups
    .map((g) => ({
      taskType: g.taskType as TaskType,
      label: TASK_BY_ID[g.taskType as TaskType].label,
      value: g._count._all,
    }))
    .sort((a, b) => b.value - a.value);

  const users = await prisma.user.findMany({
    where: { id: { in: activeGroups.map((g) => g.userId) } },
    select: { id: true, name: true, email: true },
  });
  const userMap = new Map(users.map((u) => [u.id, u]));
  const mostActiveUsers = activeGroups.map((g) => ({
    id: g.userId,
    name: userMap.get(g.userId)?.name ?? "Unknown",
    email: userMap.get(g.userId)?.email ?? "",
    generations: g._sum.count ?? 0,
  }));

  return {
    generationsToday: todayAgg._sum.count ?? 0,
    generationsThisMonth: monthAgg._sum.count ?? 0,
    userGrowth,
    newUsersPerMonth,
    dailyGenerations,
    monthlyGenerations,
    popularTasks,
    mostActiveUsers,
  };
}

const USERS_PAGE_SIZE = 20;

export async function listUsers(q: string | undefined, page: number) {
  const where: Prisma.UserWhereInput = q
    ? {
        OR: [
          { name: { contains: q, mode: "insensitive" } },
          { email: { contains: q, mode: "insensitive" } },
        ],
      }
    : {};

  const [users, total] = await Promise.all([
    prisma.user.findMany({
      where,
      orderBy: { createdAt: "desc" },
      skip: (page - 1) * USERS_PAGE_SIZE,
      take: USERS_PAGE_SIZE,
      select: {
        id: true,
        name: true,
        email: true,
        role: true,
        createdAt: true,
        onboardingCompleted: true,
        businessProfile: { select: { businessName: true, industry: true } },
        _count: { select: { generations: true } },
      },
    }),
    prisma.user.count({ where }),
  ]);

  const ids = users.map((u) => u.id);
  const monthStart = new Date(Date.UTC(new Date().getUTCFullYear(), new Date().getUTCMonth(), 1));
  const [totals, months] = await Promise.all([
    prisma.usageRecord.groupBy({ by: ["userId"], where: { userId: { in: ids } }, _sum: { count: true }, _max: { date: true } }),
    prisma.usageRecord.groupBy({ by: ["userId"], where: { userId: { in: ids }, date: { gte: monthStart } }, _sum: { count: true } }),
  ]);
  const totalMap = new Map(totals.map((t) => [t.userId, t]));
  const monthMap = new Map(months.map((m) => [m.userId, m._sum.count ?? 0]));

  return {
    total,
    page,
    pageSize: USERS_PAGE_SIZE,
    users: users.map((u) => ({
      id: u.id,
      name: u.name,
      email: u.email,
      role: u.role,
      createdAt: u.createdAt,
      onboardingCompleted: u.onboardingCompleted,
      businessName: u.businessProfile?.businessName ?? null,
      industry: u.businessProfile?.industry ?? null,
      storedGenerations: u._count.generations,
      totalGenerations: totalMap.get(u.id)?._sum.count ?? 0,
      monthGenerations: monthMap.get(u.id) ?? 0,
      lastActive: totalMap.get(u.id)?._max.date ?? null,
    })),
  };
}

export async function listActivity(take = 100) {
  const rows = await prisma.activity.findMany({
    orderBy: { createdAt: "desc" },
    take,
    include: { user: { select: { name: true } } },
  });
  return rows.map((r) => ({
    id: r.id,
    type: r.type,
    note: r.note,
    createdAt: r.createdAt,
    userName: r.user?.name ?? null,
  }));
}

export async function listReviews(status: "pending" | "approved" | "all") {
  const where: Prisma.ReviewWhereInput =
    status === "pending" ? { status: "PENDING" } : status === "approved" ? { status: "APPROVED" } : {};
  const rows = await prisma.review.findMany({
    where,
    orderBy: { createdAt: "desc" },
    take: 200,
    include: { user: { select: { name: true, email: true } } },
  });
  return rows.map((r) => ({
    id: r.id,
    rating: r.rating,
    title: r.title,
    message: r.message,
    businessName: r.businessName,
    status: r.status,
    createdAt: r.createdAt,
    userName: r.user.name,
    userEmail: r.user.email,
  }));
}
