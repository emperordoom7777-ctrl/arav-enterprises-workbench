import { withAuth } from "next-auth/middleware";

// Coarse edge guard. Every page layout and API route ALSO re-verifies
// authentication (and the ADMIN role, against the database) on the server.
export default withAuth({
  pages: { signIn: "/login" },
  callbacks: {
    authorized: ({ token, req }) => {
      if (req.nextUrl.pathname.startsWith("/admin")) return token?.role === "ADMIN";
      return Boolean(token);
    },
  },
});

export const config = {
  matcher: [
    "/dashboard/:path*",
    "/workspace/:path*",
    "/history/:path*",
    "/saved/:path*",
    "/business-profile/:path*",
    "/usage/:path*",
    "/reviews/:path*",
    "/settings/:path*",
    "/onboarding/:path*",
    "/admin/:path*",
  ],
};
