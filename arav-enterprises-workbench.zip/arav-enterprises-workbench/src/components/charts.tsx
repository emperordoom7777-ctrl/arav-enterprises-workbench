import type { SeriesPoint } from "@/lib/admin-data";

/** Server-renderable, dependency-free charts. */
export function BarChart({ data, title }: { data: SeriesPoint[]; title: string }) {
  const max = Math.max(1, ...data.map((d) => d.value));
  return (
    <figure>
      <figcaption className="sr-only">{title}</figcaption>
      <div className="flex h-44 items-end gap-1.5" role="img" aria-label={`${title}: ${data.map((d) => `${d.label} ${d.value}`).join(", ")}`}>
        {data.map((d, i) => (
          <div key={`${d.label}-${i}`} className="group flex h-full min-w-0 flex-1 flex-col justify-end" title={`${d.label}: ${d.value}`}>
            <div className="mb-1 text-center text-[10px] tabular-nums text-muted opacity-0 transition-opacity group-hover:opacity-100">{d.value}</div>
            <div className="w-full rounded-t bg-accent/80 transition-colors group-hover:bg-accent" style={{ height: `${Math.max(d.value > 0 ? 3 : 0, (d.value / max) * 100)}%` }} />
          </div>
        ))}
      </div>
      <div className="mt-2 flex gap-1.5">
        {data.map((d, i) => (
          <span key={`${d.label}-${i}`} className="min-w-0 flex-1 truncate text-center text-[10px] text-muted">
            {data.length > 14 && i % 3 !== 0 ? "" : d.label}
          </span>
        ))}
      </div>
    </figure>
  );
}

export function LineChart({ data, title }: { data: SeriesPoint[]; title: string }) {
  const w = 600;
  const h = 176;
  const pad = 6;
  const max = Math.max(1, ...data.map((d) => d.value));
  const step = data.length > 1 ? (w - pad * 2) / (data.length - 1) : 0;
  const pts = data.map((d, i) => [pad + i * step, h - pad - (d.value / max) * (h - pad * 2)] as const);
  const line = pts.map(([x, y], i) => `${i === 0 ? "M" : "L"}${x.toFixed(1)},${y.toFixed(1)}`).join(" ");
  const area = pts.length ? `${line} L${pts[pts.length - 1]![0].toFixed(1)},${h - pad} L${pts[0]![0].toFixed(1)},${h - pad} Z` : "";
  return (
    <figure>
      <svg viewBox={`0 0 ${w} ${h}`} className="h-44 w-full" preserveAspectRatio="none" role="img" aria-label={`${title}: ${data.map((d) => `${d.label} ${d.value}`).join(", ")}`}>
        {[0.25, 0.5, 0.75].map((g) => (
          <line key={g} x1={0} x2={w} y1={h * g} y2={h * g} stroke="rgb(var(--line))" strokeWidth={1} vectorEffect="non-scaling-stroke" />
        ))}
        {area && <path d={area} fill="rgb(var(--accent) / 0.12)" />}
        {line && <path d={line} fill="none" stroke="rgb(var(--accent))" strokeWidth={2} vectorEffect="non-scaling-stroke" strokeLinejoin="round" />}
      </svg>
      <div className="mt-2 flex justify-between text-[10px] text-muted">
        <span>{data[0]?.label}</span>
        <span>Peak {max.toLocaleString("en-IN")}</span>
        <span>{data[data.length - 1]?.label}</span>
      </div>
    </figure>
  );
}

export function HorizontalBars({ data }: { data: { label: string; value: number }[] }) {
  const max = Math.max(1, ...data.map((d) => d.value));
  if (data.length === 0) return <p className="py-6 text-sm text-muted">No data yet.</p>;
  return (
    <ul className="space-y-3">
      {data.map((d) => (
        <li key={d.label}>
          <div className="flex items-center justify-between text-sm">
            <span className="truncate pr-3">{d.label}</span>
            <span className="tabular-nums text-muted">{d.value.toLocaleString("en-IN")}</span>
          </div>
          <div className="mt-1.5 h-2 overflow-hidden rounded-full bg-sunken">
            <div className="h-full rounded-full bg-accent" style={{ width: `${(d.value / max) * 100}%` }} />
          </div>
        </li>
      ))}
    </ul>
  );
}
