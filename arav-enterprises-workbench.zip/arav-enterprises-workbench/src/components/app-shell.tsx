"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { signOut } from "next-auth/react";
import {
  LayoutDashboard, Sparkles, History, Bookmark, Building2, Gauge, Star, Settings, Menu, X, LogOut,
  Users, BarChart3, Cpu, Activity, ShieldCheck, ArrowLeft, type LucideIcon,
} from "lucide-react";
import { Logo } from "@/components/logo";
import { cn, initials } from "@/lib/utils";

const ICONS: Record<string, LucideIcon> = {
  dashboard: LayoutDashboard, workspace: Sparkles, history: History, saved: Bookmark, profile: Building2,
  usage: Gauge, reviews: Star, settings: Settings, users: Users, analytics: BarChart3, ai: Cpu, activity: Activity,
};

export interface NavItem {
  href: string;
  label: string;
  icon: keyof typeof ICONS;
  exact?: boolean;
}

export function AppShell({
  items,
  user,
  variant,
  showAdminLink,
  children,
}: {
  items: NavItem[];
  user: { name: string; email: string };
  variant: "user" | "admin";
  showAdminLink?: boolean;
  children: React.ReactNode;
}) {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);

  useEffect(() => setOpen(false), [pathname]);

  const isActive = (item: NavItem) => (item.exact ? pathname === item.href : pathname === item.href || pathname.startsWith(`${item.href}/`));

  const sidebar = (
    <div className="flex h-full flex-col">
      <div className="flex h-16 items-center justify-between px-4">
        <Logo href={variant === "admin" ? "/admin" : "/dashboard"} />
        <button type="button" className="btn btn-ghost btn-sm lg:hidden" onClick={() => setOpen(false)} aria-label="Close menu">
          <X className="h-4 w-4" />
        </button>
      </div>
      {variant === "admin" && (
        <p className="mx-4 mb-2 flex items-center gap-1.5 rounded-lg bg-accent-soft px-3 py-1.5 text-xs font-medium text-accent">
          <ShieldCheck className="h-3.5 w-3.5" /> Administrator
        </p>
      )}
      <nav className="flex-1 space-y-0.5 overflow-y-auto px-3 py-2" aria-label={variant === "admin" ? "Admin" : "Dashboard"}>
        {items.map((item) => {
          const Icon = ICONS[item.icon] ?? LayoutDashboard;
          const active = isActive(item);
          return (
            <Link
              key={item.href}
              href={item.href}
              aria-current={active ? "page" : undefined}
              className={cn(
                "flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors",
                active ? "bg-accent-soft text-accent" : "text-muted hover:bg-sunken hover:text-ink",
              )}
            >
              <Icon className="h-4 w-4" aria-hidden />
              {item.label}
            </Link>
          );
        })}
        {variant === "admin" ? (
          <Link href="/dashboard" className="mt-4 flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm text-muted hover:bg-sunken hover:text-ink">
            <ArrowLeft className="h-4 w-4" aria-hidden /> Back to app
          </Link>
        ) : (
          showAdminLink && (
            <Link href="/admin" className="mt-4 flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm text-muted hover:bg-sunken hover:text-ink">
              <ShieldCheck className="h-4 w-4" aria-hidden /> Admin dashboard
            </Link>
          )
        )}
      </nav>
      <div className="border-t border-line p-3">
        <div className="flex items-center gap-3 rounded-lg px-2 py-2">
          <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-accent-soft text-xs font-semibold text-accent">
            {initials(user.name)}
          </span>
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-medium">{user.name}</p>
            <p className="truncate text-xs text-muted">{user.email}</p>
          </div>
        </div>
        <button type="button" onClick={() => signOut({ callbackUrl: "/" })} className="btn btn-ghost mt-1 w-full justify-start">
          <LogOut className="h-4 w-4" /> Log out
        </button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen">
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-64 border-r border-line bg-surface lg:block">{sidebar}</aside>

      <header className="sticky top-0 z-30 flex h-14 items-center justify-between border-b border-line bg-surface/90 px-3 backdrop-blur lg:hidden">
        <button type="button" className="btn btn-ghost" onClick={() => setOpen(true)} aria-label="Open menu" aria-expanded={open}>
          <Menu className="h-5 w-5" />
        </button>
        <Logo href={variant === "admin" ? "/admin" : "/dashboard"} />
        <span className="w-10" />
      </header>

      {open && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-ink/50" onClick={() => setOpen(false)} aria-hidden />
          <div className="absolute inset-y-0 left-0 w-72 max-w-[85vw] border-r border-line bg-surface shadow-lift">{sidebar}</div>
        </div>
      )}

      <main className="lg:pl-64">
        <div className="mx-auto max-w-6xl px-4 py-6 sm:px-6 sm:py-10">{children}</div>
      </main>
    </div>
  );
}
