"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { useSearchParams } from "next/navigation";
import Link from "next/link";
import { Bookmark, BookmarkCheck, Copy, FileText, Search, Trash2 } from "lucide-react";
import type { TaskType } from "@prisma/client";
import { TASKS, TASK_BY_ID } from "@/lib/tasks";
import { api, copyText, errorMessage } from "@/lib/client";
import { useToast } from "@/components/toast";
import { ConfirmDialog, EmptyState, ErrorNotice, Modal, Skeleton, Spinner } from "@/components/ui";
import { formatDate, truncate } from "@/lib/utils";

interface Gen {
  id: string;
  taskType: TaskType;
  title: string;
  instructions: string;
  context: string | null;
  output: string;
  isSaved: boolean;
  createdAt: string;
}

interface ListResponse { items: Gen[]; total: number; hasMore: boolean }

export function GenerationList({ savedOnly }: { savedOnly?: boolean }) {
  const { toast } = useToast();
  const params = useSearchParams();
  const openParam = params.get("open");

  const [q, setQ] = useState("");
  const [debouncedQ, setDebouncedQ] = useState("");
  const [task, setTask] = useState<"" | TaskType>("");
  const [page, setPage] = useState(1);
  const [items, setItems] = useState<Gen[]>([]);
  const [total, setTotal] = useState(0);
  const [hasMore, setHasMore] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [viewing, setViewing] = useState<Gen | null>(null);
  const [deleting, setDeleting] = useState<Gen | null>(null);
  const [deleteBusy, setDeleteBusy] = useState(false);
  const openedFromUrl = useRef(false);

  useEffect(() => {
    const t = setTimeout(() => setDebouncedQ(q), 300);
    return () => clearTimeout(t);
  }, [q]);

  useEffect(() => setPage(1), [debouncedQ, task]);

  const load = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const qs = new URLSearchParams({ page: String(page) });
      if (debouncedQ) qs.set("q", debouncedQ);
      if (task) qs.set("task", task);
      if (savedOnly) qs.set("saved", "1");
      const data = await api<ListResponse>(`/api/generations?${qs.toString()}`);
      setItems((prev) => (page === 1 ? data.items : [...prev, ...data.items]));
      setTotal(data.total);
      setHasMore(data.hasMore);
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setLoading(false);
    }
  }, [page, debouncedQ, task, savedOnly]);

  useEffect(() => {
    load();
  }, [load]);

  // Open a generation linked from the dashboard (?open=ID)
  useEffect(() => {
    if (!openParam || openedFromUrl.current) return;
    openedFromUrl.current = true;
    api<{ generation: Gen }>(`/api/generations/${openParam}`)
      .then((d) => setViewing(d.generation))
      .catch(() => {});
  }, [openParam]);

  async function copy(g: Gen) {
    const ok = await copyText(g.output);
    toast(ok ? "Copied to clipboard" : "Could not copy. Select the text and copy it manually.", ok ? "success" : "error");
  }

  async function toggleSave(g: Gen) {
    try {
      const next = !g.isSaved;
      await api(`/api/generations/${g.id}`, { method: "PATCH", json: { isSaved: next } });
      const patch = (x: Gen) => (x.id === g.id ? { ...x, isSaved: next } : x);
      setItems((prev) => (savedOnly && !next ? prev.filter((x) => x.id !== g.id) : prev.map(patch)));
      if (savedOnly && !next) setTotal((t) => Math.max(0, t - 1));
      setViewing((v) => (v && v.id === g.id ? (savedOnly && !next ? null : { ...v, isSaved: next }) : v));
      toast(next ? "Saved" : "Removed from saved content");
    } catch (err) {
      toast(errorMessage(err), "error");
    }
  }

  async function confirmDelete() {
    if (!deleting) return;
    setDeleteBusy(true);
    try {
      await api(`/api/generations/${deleting.id}`, { method: "DELETE" });
      setItems((prev) => prev.filter((x) => x.id !== deleting.id));
      setTotal((t) => Math.max(0, t - 1));
      if (viewing?.id === deleting.id) setViewing(null);
      setDeleting(null);
      toast("Deleted");
    } catch (err) {
      toast(errorMessage(err), "error");
    } finally {
      setDeleteBusy(false);
    }
  }

  const filtered = Boolean(debouncedQ || task);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="page-title">{savedOnly ? "Saved Content" : "History"}</h1>
        <p className="mt-1.5 text-muted">{savedOnly ? "Your best drafts, all in one place." : "Everything you have generated."}</p>
      </div>

      <div className="flex flex-col gap-3 sm:flex-row">
        <div className="relative flex-1">
          <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted" aria-hidden />
          <input className="input pl-10" placeholder="Search" aria-label="Search" value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
        <select className="input sm:w-60" aria-label="Filter by task type" value={task} onChange={(e) => setTask(e.target.value as "" | TaskType)}>
          <option value="">All task types</option>
          {TASKS.map((t) => <option key={t.id} value={t.id}>{t.label}</option>)}
        </select>
      </div>

      {error && <ErrorNotice message={error} onRetry={load} />}

      <div className="card overflow-hidden">
        {loading && page === 1 ? (
          <div className="space-y-4 p-5">{[0, 1, 2].map((i) => <Skeleton key={i} className="h-16 w-full" />)}</div>
        ) : items.length === 0 && !error ? (
          filtered ? (
            <EmptyState icon={Search} title="No matches" description="Try a different search or task type." />
          ) : savedOnly ? (
            <EmptyState icon={Bookmark} title="No saved content yet." description="Save a generation and it will appear here." action={<Link href="/workspace" className="btn btn-primary">Open AI Workspace</Link>} />
          ) : (
            <EmptyState icon={FileText} title="No generations yet." description="Start your first AI task." action={<Link href="/workspace" className="btn btn-primary">Open AI Workspace</Link>} />
          )
        ) : (
          <ul className="divide-y divide-line">
            {items.map((g) => (
              <li key={g.id} className="flex flex-col gap-3 px-4 py-4 sm:flex-row sm:items-start sm:gap-4 sm:px-5">
                <button type="button" onClick={() => setViewing(g)} className="min-w-0 flex-1 text-left">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="badge badge-accent">{TASK_BY_ID[g.taskType].label}</span>
                    {g.isSaved && <span className="badge badge-success">Saved</span>}
                    <span className="text-xs text-muted">{formatDate(g.createdAt)}</span>
                  </div>
                  <p className="mt-2 truncate font-medium">{g.title}</p>
                  <p className="mt-1 line-clamp-2 break-words text-sm text-muted">{truncate(g.output, 220)}</p>
                </button>
                <div className="flex shrink-0 gap-1.5">
                  <button type="button" className="btn btn-ghost btn-sm" onClick={() => copy(g)} aria-label="Copy"><Copy className="h-4 w-4" /></button>
                  <button type="button" className="btn btn-ghost btn-sm" onClick={() => toggleSave(g)} aria-label={g.isSaved ? "Unsave" : "Save"}>
                    {g.isSaved ? <BookmarkCheck className="h-4 w-4 text-accent" /> : <Bookmark className="h-4 w-4" />}
                  </button>
                  <button type="button" className="btn btn-ghost btn-sm" onClick={() => setDeleting(g)} aria-label="Delete"><Trash2 className="h-4 w-4" /></button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>

      {hasMore && (
        <div className="flex justify-center">
          <button type="button" className="btn btn-secondary" onClick={() => setPage((p) => p + 1)} disabled={loading}>
            {loading && <Spinner />} Load more
          </button>
        </div>
      )}
      {!loading && items.length > 0 && <p className="text-center text-xs text-muted">{total} item{total === 1 ? "" : "s"}</p>}

      <Modal open={Boolean(viewing)} onClose={() => setViewing(null)} title={viewing?.title ?? ""} wide>
        {viewing && (
          <div className="space-y-4">
            <div className="flex flex-wrap items-center gap-2">
              <span className="badge badge-accent">{TASK_BY_ID[viewing.taskType].label}</span>
              <span className="text-xs text-muted">{formatDate(viewing.createdAt, true)}</span>
            </div>
            <div className="whitespace-pre-wrap break-words rounded-xl bg-sunken p-4 text-[15px] leading-relaxed">{viewing.output}</div>
            <details className="text-sm">
              <summary className="cursor-pointer text-muted">Original instructions</summary>
              <p className="mt-2 whitespace-pre-wrap break-words text-muted">{viewing.instructions}</p>
              {viewing.context && <p className="mt-2 whitespace-pre-wrap break-words text-muted">Context: {viewing.context}</p>}
            </details>
            <div className="flex flex-wrap justify-end gap-2">
              <button type="button" className="btn btn-secondary" onClick={() => copy(viewing)}><Copy className="h-4 w-4" /> Copy</button>
              <button type="button" className="btn btn-secondary" onClick={() => toggleSave(viewing)}>
                {viewing.isSaved ? <BookmarkCheck className="h-4 w-4 text-accent" /> : <Bookmark className="h-4 w-4" />} {viewing.isSaved ? "Unsave" : "Save"}
              </button>
              <button type="button" className="btn btn-secondary text-danger" onClick={() => setDeleting(viewing)}><Trash2 className="h-4 w-4" /> Delete</button>
            </div>
          </div>
        )}
      </Modal>

      <ConfirmDialog
        open={Boolean(deleting)}
        title="Delete this generation?"
        message="This permanently removes it from your history and saved content. It will not give back the usage it counted."
        busy={deleteBusy}
        onConfirm={confirmDelete}
        onCancel={() => setDeleting(null)}
      />
    </div>
  );
}
