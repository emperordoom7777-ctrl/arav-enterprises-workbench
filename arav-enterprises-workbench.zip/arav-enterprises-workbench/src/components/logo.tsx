import Link from "next/link";
import { cn } from "@/lib/utils";

export function Logo({ href = "/", className }: { href?: string; className?: string }) {
  return (
    <Link href={href} className={cn("inline-flex items-center gap-2.5", className)} aria-label="Arav Enterprises Workbench home">
      <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-accent text-accent-ink">
        <svg viewBox="0 0 24 24" className="h-4.5 w-4.5" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
          <path d="M4 19 12 5l8 14" />
          <path d="M7.5 14h9" />
        </svg>
      </span>
      <span className="font-display text-[15px] font-semibold leading-none tracking-tight">
        Arav Enterprises <span className="text-muted">Workbench</span>
      </span>
    </Link>
  );
}
