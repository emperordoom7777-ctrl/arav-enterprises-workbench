import type { Config } from "tailwindcss";

const withAlpha = (name: string) => `rgb(var(--${name}) / <alpha-value>)`;

const config: Config = {
  darkMode: "class",
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        canvas: withAlpha("canvas"),
        surface: withAlpha("surface"),
        sunken: withAlpha("sunken"),
        line: withAlpha("line"),
        ink: withAlpha("ink"),
        muted: withAlpha("muted"),
        accent: {
          DEFAULT: withAlpha("accent"),
          ink: withAlpha("accent-ink"),
          soft: withAlpha("accent-soft"),
        },
        success: withAlpha("success"),
        danger: withAlpha("danger"),
        warn: withAlpha("warn"),
      },
      fontFamily: {
        display: ["var(--font-display)", "ui-sans-serif", "system-ui", "sans-serif"],
        sans: ["var(--font-sans)", "ui-sans-serif", "system-ui", "sans-serif"],
      },
      boxShadow: {
        card: "0 1px 2px rgb(var(--ink) / 0.04)",
        lift: "0 8px 30px rgb(var(--ink) / 0.08)",
      },
    },
  },
  plugins: [],
};

export default config;
